import { useState, useEffect } from 'react';
import { v4 as uuidv4 } from 'uuid';
import { 
  UserProfile, 
  getUserProfile, 
  createOrUpdateUser, 
  saveSignalHistory,
  checkSubscriptionStatus,
  resetDailySignalsIfNeeded
} from '../lib/supabase';

export const useUserData = () => {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [userId, setUserId] = useState<string>('');

  useEffect(() => {
    initializeUser();
  }, []);

  const initializeUser = async () => {
    try {
      // For now, use localStorage as primary storage since we don't have a real Supabase setup
      initializeLocalUser();
      return;
      
      // Get or create user ID
      let storedUserId = localStorage.getItem('aviator_user_id');
      if (!storedUserId) {
        storedUserId = uuidv4();
        localStorage.setItem('aviator_user_id', storedUserId);
      }
      setUserId(storedUserId);

      // Try to get user from database
      const { data: existingUser, error } = await getUserProfile(storedUserId);
      
      if (error && error.code !== 'PGRST116') {
        console.error('Error fetching user:', error);
      }

      if (existingUser) {
        // Reset daily signals if needed
        const updatedUser = await resetDailySignalsIfNeeded(existingUser);
        setUser(updatedUser);
      } else {
        // Create new user
        const newUser: Partial<UserProfile> = {
          id: storedUserId,
          daily_signal_count: 0,
          total_signal_count: 0,
          subscription_type: 'free',
          recent_signals: [],
          last_reset_date: new Date().toISOString(),
          created_at: new Date().toISOString()
        };

        const { data: createdUser } = await createOrUpdateUser(storedUserId, newUser);
        if (createdUser) {
          setUser(createdUser);
        }
      }
    } catch (error) {
      console.error('Error initializing user:', error);
      // Fallback to localStorage
      initializeLocalUser();
    } finally {
      setLoading(false);
    }
  };

  const initializeLocalUser = () => {
    const localData = localStorage.getItem('aviator_user_data');
    if (localData) {
      const userData = JSON.parse(localData);
      // Reset daily count if it's a new day
      const today = new Date().toDateString();
      const lastResetDate = new Date(userData.last_reset_date || 0).toDateString();
      
      if (today !== lastResetDate) {
        userData.daily_signal_count = 0;
        userData.last_reset_date = new Date().toISOString();
      }
      
      setUser(userData);
    } else {
      const newUser: UserProfile = {
        id: userId || uuidv4(),
        daily_signal_count: 0,
        total_signal_count: 0,
        subscription_type: 'free',
        recent_signals: [],
        last_reset_date: new Date().toISOString(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };
      setUser(newUser);
      localStorage.setItem('aviator_user_data', JSON.stringify(newUser));
    }
  };

  const updateUser = async (updates: Partial<UserProfile>) => {
    if (!user) return;

    const updatedUser = { ...user, ...updates, updated_at: new Date().toISOString() };
    setUser(updatedUser);

    try {
      await createOrUpdateUser(user.id, updatedUser);
    } catch (error) {
      console.error('Error updating user in database:', error);
    }

    // Also update localStorage as backup
    localStorage.setItem('aviator_user_data', JSON.stringify(updatedUser));
  };

  const addSignal = async (signalValue: string, platform: string) => {
    if (!user) return;

    const newRecentSignals = [signalValue, ...user.recent_signals].slice(0, 10);
    
    await updateUser({
      daily_signal_count: user.daily_signal_count + 1,
      total_signal_count: user.total_signal_count + 1,
      recent_signals: newRecentSignals
    });

    // Save to signal history
    try {
      await saveSignalHistory(user.id, signalValue, platform);
    } catch (error) {
      console.error('Error saving signal history:', error);
    }
  };

  const upgradeSubscription = async (type: 'weekly' | 'monthly' | 'yearly') => {
    if (!user) return;

    const now = new Date();
    let expiryDate: Date;

    switch (type) {
      case 'weekly':
        expiryDate = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);
        break;
      case 'monthly':
        expiryDate = new Date(now.getTime() + 30 * 24 * 60 * 60 * 1000);
        break;
      case 'yearly':
        expiryDate = new Date(now.getTime() + 365 * 24 * 60 * 60 * 1000);
        break;
    }

    await updateUser({
      subscription_type: type,
      subscription_expires_at: expiryDate.toISOString()
    });
  };

  const isSubscriptionActive = (): boolean => {
    if (!user) return false;
    return checkSubscriptionStatus(user);
  };

  const canGenerateSignal = (): boolean => {
    if (!user) return false;
    
    // Premium users can generate unlimited signals
    if (isSubscriptionActive()) return true;
    
    // Free users can generate up to 5 signals per day
    return user.daily_signal_count < 5;
  };

  return {
    user,
    loading,
    updateUser,
    addSignal,
    upgradeSubscription,
    isSubscriptionActive,
    canGenerateSignal
  };
};