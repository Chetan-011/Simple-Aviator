import { useState, useEffect } from 'react';

interface BeforeInstallPromptEvent extends Event {
  readonly platforms: string[];
  readonly userChoice: Promise<{
    outcome: 'accepted' | 'dismissed';
    platform: string;
  }>;
  prompt(): Promise<void>;
}

export const usePWA = () => {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstallable, setIsInstallable] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);

  useEffect(() => {
    // Check if app is already installed
    const isStandalone = window.matchMedia('(display-mode: standalone)').matches;
    const isInWebAppiOS = (window.navigator as any).standalone === true;
    const isInstalled = isStandalone || isInWebAppiOS;
    
    setIsInstalled(isInstalled);

    // If not installed, check for installability
    if (!isInstalled) {
      // For browsers that support beforeinstallprompt
      const handleBeforeInstallPrompt = (e: Event) => {
        e.preventDefault();
        setDeferredPrompt(e as BeforeInstallPromptEvent);
        setIsInstallable(true);
      };

      // For browsers that don't support beforeinstallprompt (like iOS Safari)
      const checkInstallability = () => {
        const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
        const isAndroid = /Android/.test(navigator.userAgent);
        const isDesktop = !isIOS && !isAndroid;
        
        // Show install prompt for all platforms if not already installed
        if (!isInstalled) {
          setIsInstallable(true);
        }
      };

      window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      
      // Check installability after a short delay
      setTimeout(checkInstallability, 2000);

      // Listen for appinstalled event
      const handleAppInstalled = () => {
        setIsInstalled(true);
        setIsInstallable(false);
        setDeferredPrompt(null);
      };

      window.addEventListener('appinstalled', handleAppInstalled);

      return () => {
        window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
        window.removeEventListener('appinstalled', handleAppInstalled);
      };
    }
  }, []);

  const installApp = async () => {
    try {
      if (deferredPrompt) {
        // For browsers with beforeinstallprompt support
        await deferredPrompt.prompt();
        const { outcome } = await deferredPrompt.userChoice;
        
        if (outcome === 'accepted') {
          setDeferredPrompt(null);
          setIsInstallable(false);
          setIsInstalled(true);
          return true;
        }
      } else {
        // For browsers without beforeinstallprompt support (like iOS Safari)
        // Show manual installation instructions
        const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
        const isAndroid = /Android/.test(navigator.userAgent);
        
        if (isIOS) {
          // Create a more user-friendly iOS installation guide
          const installGuide = document.createElement('div');
          installGuide.innerHTML = `
            <div style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.9); z-index: 10000; display: flex; align-items: center; justify-content: center; padding: 20px;">
              <div style="background: white; border-radius: 12px; padding: 24px; max-width: 400px; text-align: center;">
                <h3 style="margin: 0 0 16px 0; color: #333;">Install Aviator Signals</h3>
                <p style="margin: 0 0 20px 0; color: #666; font-size: 14px;">
                  1. Tap the Share button (📤) at the bottom<br>
                  2. Scroll down and tap "Add to Home Screen"<br>
                  3. Tap "Add" to install the app
                </p>
                <button onclick="this.parentElement.parentElement.remove()" style="background: #007AFF; color: white; border: none; padding: 12px 24px; border-radius: 8px; font-size: 16px;">Got it!</button>
              </div>
            </div>
          `;
          document.body.appendChild(installGuide);
        } else if (isAndroid) {
          // Create a more user-friendly Android installation guide
          const installGuide = document.createElement('div');
          installGuide.innerHTML = `
            <div style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.9); z-index: 10000; display: flex; align-items: center; justify-content: center; padding: 20px;">
              <div style="background: white; border-radius: 12px; padding: 24px; max-width: 400px; text-align: center;">
                <h3 style="margin: 0 0 16px 0; color: #333;">Install Aviator Signals</h3>
                <p style="margin: 0 0 20px 0; color: #666; font-size: 14px;">
                  1. Tap the menu (⋮) in your browser<br>
                  2. Select "Add to Home screen" or "Install app"<br>
                  3. Tap "Add" or "Install" to confirm
                </p>
                <button onclick="this.parentElement.parentElement.remove()" style="background: #4CAF50; color: white; border: none; padding: 12px 24px; border-radius: 8px; font-size: 16px;">Got it!</button>
              </div>
            </div>
          `;
          document.body.appendChild(installGuide);
        } else {
          // Create a more user-friendly desktop installation guide
          const installGuide = document.createElement('div');
          installGuide.innerHTML = `
            <div style="position: fixed; top: 0; left: 0; right: 0; bottom: 0; background: rgba(0,0,0,0.9); z-index: 10000; display: flex; align-items: center; justify-content: center; padding: 20px;">
              <div style="background: white; border-radius: 12px; padding: 24px; max-width: 400px; text-align: center;">
                <h3 style="margin: 0 0 16px 0; color: #333;">Install Aviator Signals</h3>
                <p style="margin: 0 0 20px 0; color: #666; font-size: 14px;">
                  1. Look for the install icon (⊕) in your browser's address bar<br>
                  2. Click the install button<br>
                  3. Confirm installation in the popup
                </p>
                <button onclick="this.parentElement.parentElement.remove()" style="background: #2196F3; color: white; border: none; padding: 12px 24px; border-radius: 8px; font-size: 16px;">Got it!</button>
              </div>
            </div>
          `;
          document.body.appendChild(installGuide);
        }
        
        return true;
      }
    } catch (error) {
      console.error('Error installing app:', error);
    }
    
    return false;
  };

  return {
    isInstallable: isInstallable && !isInstalled,
    isInstalled,
    installApp
  };
};