export interface Task {
  id: number;
  image: string;
  story: string;
  category: string;
}

const tasks: Task[] = [
  {
    id: 1,
    image: "https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&w=600",
    story: "In the heart of a bustling city, Sarah discovered an old bookstore tucked between two modern buildings. The wooden door creaked as she entered, revealing shelves that stretched from floor to ceiling, filled with countless stories waiting to be discovered. The elderly owner, Mr. Chen, greeted her with a warm smile and twinkling eyes. He had been running this magical place for over forty years, watching generations of readers find their perfect books. Sarah spent hours browsing through the collection, eventually finding a leather-bound journal that seemed to call out to her. As she opened it, she realized it was blank, waiting for her own story to begin. Mr. Chen noticed her fascination and whispered, 'Every great story starts with a single word.' That day, Sarah began writing her first novel in that very bookstore.",
    category: "bookstore"
  },
  {
    id: 2,
    image: "https://images.pexels.com/photos/1640777/pexels-photo-1640777.jpeg?auto=compress&cs=tinysrgb&w=600",
    story: "The morning sun cast golden rays through the kitchen window as Emma prepared breakfast for her family. The aroma of freshly brewed coffee filled the air, mixing with the scent of warm pancakes on the griddle. Her children rushed downstairs, their faces bright with excitement for the day ahead. Emma smiled as she watched them gather around the table, sharing stories about their dreams from the night before. This simple morning ritual had become the foundation of their family bond. As they ate together, Emma realized that these precious moments were what made their house truly feel like home. The laughter and love shared over breakfast would carry them through whatever challenges the day might bring.",
    category: "family"
  },
  {
    id: 3,
    image: "https://images.pexels.com/photos/1366919/pexels-photo-1366919.jpeg?auto=compress&cs=tinysrgb&w=600",
    story: "The mountain trail stretched endlessly before Jake as he continued his solo hiking adventure. Each step brought him closer to the summit, but also deeper into his own thoughts. The crisp mountain air filled his lungs as he paused to admire the breathtaking view of the valley below. Wildlife rustled in the nearby bushes, reminding him that he was a guest in this natural sanctuary. As the sun began to set, painting the sky in brilliant shades of orange and pink, Jake felt a profound sense of peace wash over him. This journey wasn't just about reaching the top of the mountain; it was about discovering the strength and resilience within himself. With renewed determination, he continued his ascent toward the peak.",
    category: "adventure"
  },
  {
    id: 4,
    image: "https://images.pexels.com/photos/1181676/pexels-photo-1181676.jpeg?auto=compress&cs=tinysrgb&w=600",
    story: "The small coastal town came alive every evening as the fishing boats returned from their daily voyage. Maria stood on the weathered pier, watching her father's boat approach through the gentle waves. The salty breeze carried the sounds of seagulls and the distant laughter of children playing on the beach. This routine had remained unchanged for generations, connecting the present to the rich maritime heritage of their community. As the boats docked, families gathered to welcome their loved ones home and share in the day's catch. Maria felt grateful to be part of this timeless tradition, where the rhythm of the ocean dictated the pace of life. The setting sun reflected off the water, creating a perfect end to another day in their peaceful harbor town.",
    category: "coastal"
  },
  {
    id: 5,
    image: "https://images.pexels.com/photos/1181244/pexels-photo-1181244.jpeg?auto=compress&cs=tinysrgb&w=600",
    story: "The art studio buzzed with creative energy as students worked on their latest masterpieces. Canvas after canvas displayed unique interpretations of the same still life arrangement. Professor Williams moved quietly between the easels, offering gentle guidance and encouragement to each aspiring artist. The afternoon light streaming through the large windows created perfect conditions for capturing the subtle shadows and highlights of their subjects. For many students, this class represented more than just learning technique; it was a journey of self-discovery and expression. As brushes danced across canvases, dreams took shape in vibrant colors and bold strokes. The studio had become a sanctuary where creativity flourished and artistic souls found their voice.",
    category: "art"
  },
  {
    id: 6,
    image: "https://images.pexels.com/photos/1181298/pexels-photo-1181298.jpeg?auto=compress&cs=tinysrgb&w=600",
    story: "The old lighthouse stood majestically on the rocky cliff, its beacon cutting through the thick fog that had rolled in from the sea. Captain Roberts had been the lighthouse keeper for over thirty years, faithfully maintaining the light that guided ships safely to shore. Tonight felt different somehow, as if the lighthouse itself was telling him stories of all the vessels it had helped navigate through treacherous waters. The rhythmic sound of waves crashing against the rocks below provided a constant soundtrack to his solitary vigil. As dawn approached, the fog began to lift, revealing a calm sea that sparkled like diamonds in the early morning light. Captain Roberts smiled, knowing that once again, his lighthouse had served its noble purpose of bringing travelers safely home.",
    category: "lighthouse"
  },
  {
    id: 7,
    image: "https://images.pexels.com/photos/1181345/pexels-photo-1181345.jpeg?auto=compress&cs=tinysrgb&w=600",
    story: "The bustling marketplace came alive at dawn as vendors set up their colorful stalls filled with fresh produce, handmade crafts, and aromatic spices. Anna loved her weekly visits to this vibrant hub of community life, where neighbors became friends and strangers shared stories over steaming cups of tea. The air was filled with the sounds of friendly bargaining, children's laughter, and the melodic calls of vendors advertising their wares. Each stall told a unique story of family traditions passed down through generations. As Anna made her way through the maze of booths, she collected not just groceries for the week, but also memories and connections that enriched her life. The marketplace was more than a place of commerce; it was the beating heart of their community.",
    category: "marketplace"
  },
  {
    id: 8,
    image: "https://images.pexels.com/photos/1181406/pexels-photo-1181406.jpeg?auto=compress&cs=tinysrgb&w=600",
    story: "The ancient forest whispered secrets to those who took time to listen. Dr. Elena Martinez, a botanist studying rare plant species, carefully documented each discovery in her weathered field notebook. Shafts of sunlight filtered through the dense canopy above, creating a natural cathedral of green. Every step revealed new wonders: exotic flowers, unusual fungi, and trees that had stood for centuries. The forest ecosystem was a delicate balance of life, death, and renewal that fascinated Elena beyond measure. As she worked, she felt a deep connection to the natural world and a responsibility to protect these precious habitats for future generations. Her research would contribute to conservation efforts that could preserve this magical place forever.",
    category: "forest"
  },
  {
    id: 9,
    image: "https://images.pexels.com/photos/1181534/pexels-photo-1181534.jpeg?auto=compress&cs=tinysrgb&w=600",
    story: "The vintage train station buzzed with excitement as passengers prepared for their journey across the countryside. Thomas, the station master, had witnessed countless departures and arrivals over his forty-year career. Each train carried dreams, hopes, and stories of people seeking new adventures or returning to beloved homes. The rhythmic sound of the approaching locomotive filled the air, accompanied by the hiss of steam and the conductor's familiar call. Families embraced on the platform, some saying goodbye and others celebrating reunions. As the train pulled away from the station, Thomas waved farewell, knowing that each passenger was embarking on their own unique chapter of life's great adventure.",
    category: "train"
  },
  {
    id: 10,
    image: "https://images.pexels.com/photos/1181712/pexels-photo-1181712.jpeg?auto=compress&cs=tinysrgb&w=600",
    story: "The cozy coffee shop on the corner had become the unofficial meeting place for the neighborhood's creative community. Writers typed away on laptops, artists sketched in notebooks, and musicians quietly strummed guitars in the corner booth. The barista, Miguel, knew everyone's usual order and had a talent for creating the perfect atmosphere for inspiration to flourish. The walls were adorned with local artwork that changed monthly, giving emerging artists a chance to showcase their talents. As the afternoon sun streamed through the large windows, casting warm light across the wooden tables, the coffee shop hummed with the quiet energy of dreams being pursued. This little haven had become more than just a place for caffeine; it was where community and creativity intersected.",
    category: "coffee"
  }
];

export const generateRandomTask = (): Task => {
  const randomIndex = Math.floor(Math.random() * tasks.length);
  return tasks[randomIndex];
};

export const getTaskById = (id: number): Task | undefined => {
  return tasks.find(task => task.id === id);
};

export const getTasksByCategory = (category: string): Task[] => {
  return tasks.filter(task => task.category === category);
};