import React, { useState, useEffect } from 'react';
import { useUserData } from './hooks/useUserData';
import WelcomeScreen from './components/WelcomeScreen';
import AccessCodeScreen from './components/AccessCodeScreen';
import PlatformSelectionScreen from './components/PlatformSelectionScreen';
import SignalGenerator from './components/SignalGenerator';
import GetCodeScreen from './components/GetCodeScreen';
import InstallPrompt from './components/InstallPrompt';
import PrivacyPolicy from './components/PrivacyPolicy';
import TermsOfService from './components/TermsOfService';
import { requestNotificationPermission } from './utils/notifications';

function App() {
  const { loading } = useUserData();
  const [currentScreen, setCurrentScreen] = useState<'welcome' | 'access' | 'platform' | 'generator' | 'getcode'>('welcome');
  const [selectedPlatform, setSelectedPlatform] = useState<string>('');
  const [showPrivacyPolicy, setShowPrivacyPolicy] = useState(false);
  const [showTermsOfService, setShowTermsOfService] = useState(false);

  useEffect(() => {
    // Request notification permission on app load
    requestNotificationPermission();
    
    // Debug logging
    console.log('Current screen:', currentScreen);
    console.log('Selected platform:', selectedPlatform);
  }, []);

  useEffect(() => {
    console.log('Screen changed to:', currentScreen);
    console.log('Platform is:', selectedPlatform);
  }, [currentScreen, selectedPlatform]);
  const handleWelcomeProceed = () => {
    console.log('Welcome proceed clicked');
    setCurrentScreen('access');
  };

  const handleAccessGranted = () => {
    console.log('Access granted');
    setCurrentScreen('platform');
  };

  const handlePlatformSelected = (platform: string) => {
    console.log('Platform selected:', platform);
    setSelectedPlatform(platform);
    setCurrentScreen('generator');
  };

  const handleGetCode = () => {
    console.log('Get code clicked');
    setCurrentScreen('getcode');
  };

  const handleBackToAccess = () => {
    console.log('Back to access clicked');
    setCurrentScreen('access');
  };

  // Debug render
  console.log('Rendering App with screen:', currentScreen, 'platform:', selectedPlatform);
  
  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-red-800 flex items-center justify-center">
        <div className="text-white text-center">
          <div className="animate-spin rounded-full h-32 w-32 border-b-2 border-white mx-auto mb-4"></div>
          <p className="text-xl font-bold" style={{ fontFamily: 'Orbitron, monospace' }}>
            Loading Aviator Hackbot...
          </p>
        </div>
      </div>
    );
  }
  
  return (
    <div className="App">
      {currentScreen === 'welcome' && (
        <WelcomeScreen onProceed={handleWelcomeProceed} />
      )}
      {currentScreen === 'access' && (
        <AccessCodeScreen 
          onAccessGranted={handleAccessGranted} 
          onGetCode={handleGetCode}
        />
      )}
      {currentScreen === 'platform' && (
        <PlatformSelectionScreen 
          onPlatformSelected={handlePlatformSelected}
        />
      )}
      {currentScreen === 'generator' && (
        <SignalGenerator selectedPlatform={selectedPlatform} />
      )}
      {currentScreen === 'getcode' && (
        <GetCodeScreen onBack={handleBackToAccess} />
      )}
      
      {/* PWA Install Prompt */}
      <InstallPrompt />
      
      {/* Legal Modals */}
      <PrivacyPolicy 
        isOpen={showPrivacyPolicy} 
        onClose={() => setShowPrivacyPolicy(false)} 
      />
      
      <TermsOfService 
        isOpen={showTermsOfService} 
        onClose={() => setShowTermsOfService(false)} 
      />
    </div>
  );
}

export default App;