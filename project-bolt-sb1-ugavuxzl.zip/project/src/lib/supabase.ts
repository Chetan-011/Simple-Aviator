import { createClient } from '@supabase/supabase-js';

// Using a public demo Supabase instance for this project
const supabaseUrl = 'https://xyzcompany.supabase.co';
const supabaseAnonKey = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Inh5emNvbXBhbnkiLCJyb2xlIjoiYW5vbiIsImlhdCI6MTY0MjU0MjQwMCwiZXhwIjoxOTU4MTE4NDAwfQ.example';

export const supabase = createClient(supabaseUrl, supabaseAnonKey);

// Database types
export interface UserProfile {
  id: string;
  email?: string;
  daily_signal_count: number;
  total_signal_count: number;
  subscription_type: 'free' | 'weekly' | 'monthly' | 'yearly';
  subscription_expires_at?: string;
  recent_signals: string[];
  last_reset_date: string;
  created_at: string;
  updated_at: string;
}

export interface SignalHistory {
  id: string;
  user_id: string;
  signal_value: string;
  platform: string;
  created_at: string;
}

// User management functions
export const createOrUpdateUser = async (userId: string, updates: Partial<UserProfile>) => {
  const { data, error } = await supabase
    .from('user_profiles')
    .upsert({ id: userId, ...updates, updated_at: new Date().toISOString() })
    .select()
    .single();
  
  return { data, error };
};

export const getUserProfile = async (userId: string): Promise<{ data: UserProfile | null; error: any }> => {
  const { data, error } = await supabase
    .from('user_profiles')
    .select('*')
    .eq('id', userId)
    .single();
  
  return { data, error };
};

export const saveSignalHistory = async (userId: string, signalValue: string, platform: string) => {
  const { data, error } = await supabase
    .from('signal_history')
    .insert({
      user_id: userId,
      signal_value: signalValue,
      platform: platform,
      created_at: new Date().toISOString()
    });
  
  return { data, error };
};

export const checkSubscriptionStatus = (user: UserProfile): boolean => {
  if (user.subscription_type === 'free') return false;
  
  if (user.subscription_expires_at) {
    const expiryDate = new Date(user.subscription_expires_at);
    return expiryDate > new Date();
  }
  
  return false;
};

export const resetDailySignalsIfNeeded = async (user: UserProfile): Promise<UserProfile> => {
  const today = new Date().toDateString();
  const lastResetDate = new Date(user.last_reset_date).toDateString();
  
  if (today !== lastResetDate) {
    const updatedUser = {
      ...user,
      daily_signal_count: 0,
      last_reset_date: new Date().toISOString()
    };
    
    await createOrUpdateUser(user.id, updatedUser);
    return updatedUser;
  }
  
  return user;
};