import React from 'react';
import { X, Shield, Eye, Lock, Database } from 'lucide-react';

interface PrivacyPolicyProps {
  isOpen: boolean;
  onClose: () => void;
}

const PrivacyPolicy: React.FC<PrivacyPolicyProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-br from-black/90 to-blue-900/20 border border-blue-500/30 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-3">
              <Shield className="text-blue-400" size={32} />
              <h2 className="text-3xl font-bold text-white" style={{ fontFamily: 'Orbitron, monospace' }}>
                Privacy Policy
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-blue-300 transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          <div className="space-y-6 text-white">
            <div className="bg-black/50 border border-blue-500/30 rounded-lg p-4">
              <p className="text-blue-300 text-sm">
                <strong>Last Updated:</strong> January 2025
              </p>
              <p className="text-white/80 text-sm mt-2">
                This Privacy Policy explains how Aviator Predictor ("we," "our," or "us") collects, uses, and protects your information.
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Database className="text-green-400 mt-1" size={20} />
                <div>
                  <h3 className="text-xl font-bold mb-2" style={{ fontFamily: 'Orbitron, monospace' }}>
                    Information We Collect
                  </h3>
                  <ul className="text-white/80 space-y-2 text-sm">
                    <li>• Usage data and app interactions</li>
                    <li>• Device information and technical specifications</li>
                    <li>• Payment information for subscription processing</li>
                    <li>• Communication data when you contact support</li>
                  </ul>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Eye className="text-yellow-400 mt-1" size={20} />
                <div>
                  <h3 className="text-xl font-bold mb-2" style={{ fontFamily: 'Orbitron, monospace' }}>
                    How We Use Your Information
                  </h3>
                  <ul className="text-white/80 space-y-2 text-sm">
                    <li>• Provide and improve our prediction services</li>
                    <li>• Process payments and manage subscriptions</li>
                    <li>• Send important updates and notifications</li>
                    <li>• Analyze usage patterns to enhance user experience</li>
                    <li>• Provide customer support and technical assistance</li>
                  </ul>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Lock className="text-red-400 mt-1" size={20} />
                <div>
                  <h3 className="text-xl font-bold mb-2" style={{ fontFamily: 'Orbitron, monospace' }}>
                    Data Protection
                  </h3>
                  <ul className="text-white/80 space-y-2 text-sm">
                    <li>• All data is encrypted using industry-standard protocols</li>
                    <li>• We never share your personal information with third parties</li>
                    <li>• Payment processing is handled by secure, certified providers</li>
                    <li>• Regular security audits and updates are performed</li>
                    <li>• Data retention policies ensure information is not kept longer than necessary</li>
                  </ul>
                </div>
              </div>

              <div className="bg-green-900/30 border border-green-500/50 rounded-lg p-4">
                <h3 className="text-green-300 font-bold mb-2">Your Rights</h3>
                <ul className="text-green-200 text-sm space-y-1">
                  <li>• Request access to your personal data</li>
                  <li>• Request correction of inaccurate information</li>
                  <li>• Request deletion of your data</li>
                  <li>• Opt-out of marketing communications</li>
                  <li>• Data portability upon request</li>
                </ul>
              </div>

              <div className="bg-yellow-900/30 border border-yellow-500/50 rounded-lg p-4">
                <h3 className="text-yellow-300 font-bold mb-2">Cookies and Tracking</h3>
                <p className="text-yellow-200 text-sm">
                  We use essential cookies to ensure proper app functionality. Analytics cookies help us improve our services. 
                  You can control cookie preferences in your browser settings.
                </p>
              </div>

              <div className="bg-red-900/30 border border-red-500/50 rounded-lg p-4">
                <h3 className="text-red-300 font-bold mb-2">Important Notice</h3>
                <p className="text-red-200 text-sm">
                  This app is for entertainment purposes only. We do not encourage gambling and recommend responsible gaming practices. 
                  Please ensure compliance with your local laws and regulations.
                </p>
              </div>
            </div>

            <div className="border-t border-white/20 pt-6">
              <h3 className="text-xl font-bold mb-4" style={{ fontFamily: 'Orbitron, monospace' }}>
                Contact Us
              </h3>
              <p className="text-white/80 mb-4">
                If you have any questions about this Privacy Policy, please contact us:
              </p>
              <div className="space-y-2">
                <p className="text-blue-400">
                  <strong>Email:</strong> chetanagarwalla06@gmail.com
                </p>
                <p className="text-green-400">
                  <strong>Telegram:</strong> @aviatorpredictorXYZ100
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PrivacyPolicy;