import React from 'react';
import { Download, X, Smartphone, Plus } from 'lucide-react';
import { usePWA } from '../hooks/usePWA';

const InstallPrompt: React.FC = () => {
  const { isInstallable, installApp } = usePWA();
  const [showPrompt, setShowPrompt] = React.useState(false);
  const [showManualInstructions, setShowManualInstructions] = React.useState(false);

  React.useEffect(() => {
    if (isInstallable) {
      // Show prompt after 10 seconds
      const timer = setTimeout(() => {
        setShowPrompt(true);
      }, 10000);

      return () => clearTimeout(timer);
    }
  }, [isInstallable]);

  const handleInstall = () => {
    installApp().then((success) => {
      if (success) {
        setShowPrompt(false);
      } else {
        // Show manual installation instructions
        setShowManualInstructions(true);
      }
    });
  };

  const getManualInstructions = () => {
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
    const isAndroid = /Android/.test(navigator.userAgent);
    
    if (isIOS) {
      return {
        title: "Install on iOS",
        steps: [
          "1. Tap the Share button (square with arrow)",
          "2. Scroll down and tap 'Add to Home Screen'",
          "3. Tap 'Add' to confirm installation",
          "4. Find the app icon on your home screen"
        ]
      };
    } else if (isAndroid) {
      return {
        title: "Install on Android",
        steps: [
          "1. Tap the menu (⋮) in your browser",
          "2. Select 'Add to Home screen' or 'Install app'",
          "3. Tap 'Add' or 'Install' to confirm",
          "4. Find the app icon on your home screen"
        ]
      };
    } else {
      return {
        title: "Install on Desktop",
        steps: [
          "1. Look for the install icon (⊕) in the address bar",
          "2. Click the install button",
          "3. Confirm installation in the popup",
          "4. Access the app from your desktop or start menu"
        ]
      };
    }
  };

  if (!showPrompt && !showManualInstructions) return null;

  if (showManualInstructions) {
    const instructions = getManualInstructions();
    
    return (
      <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
        <div className="bg-gradient-to-br from-black/90 to-red-900/20 border border-red-500/30 rounded-2xl max-w-md w-full">
          <div className="p-6">
            <div className="flex justify-between items-center mb-6">
              <div className="flex items-center gap-3">
                <div className="bg-red-600 p-2 rounded-lg">
                  <Smartphone className="text-white" size={24} />
                </div>
                <h3 className="text-white font-bold text-lg" style={{ fontFamily: 'Orbitron, monospace' }}>
                  {instructions.title}
                </h3>
              </div>
              <button
                onClick={() => setShowManualInstructions(false)}
                className="text-white hover:text-red-300 transition-colors"
              >
                <X size={20} />
              </button>
            </div>
            
            <div className="space-y-3 mb-6">
              {instructions.steps.map((step, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="bg-red-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">
                    {index + 1}
                  </div>
                  <p className="text-white/80 text-sm">{step.substring(3)}</p>
                </div>
              ))}
            </div>
            
            <div className="bg-green-900/30 border border-green-500/50 rounded-lg p-4 mb-4">
              <p className="text-green-300 text-sm font-bold mb-2">Why Install?</p>
              <ul className="text-green-200 text-xs space-y-1">
                <li>• Faster loading and offline access</li>
                <li>• Push notifications for new signals</li>
                <li>• Full-screen experience</li>
                <li>• Quick access from home screen</li>
              </ul>
            </div>
            
            <button
              onClick={() => setShowManualInstructions(false)}
              className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300"
              style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}
            >
              Got It!
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed bottom-4 left-4 right-4 z-50 md:left-auto md:right-4 md:max-w-sm">
      <div className="bg-gradient-to-r from-red-600 to-red-700 border border-red-500 rounded-xl p-4 shadow-2xl backdrop-blur-sm animate-bounce">
        <div className="flex items-start gap-3">
          <div className="bg-white/20 p-2 rounded-lg">
            <Smartphone className="text-white" size={24} />
          </div>
          
          <div className="flex-1">
            <h3 className="text-white font-bold text-sm mb-1" style={{ fontFamily: 'Orbitron, monospace' }}>
              Install Aviator Signals
            </h3>
            <p className="text-white/80 text-xs mb-3">
              Get instant access to signals directly from your home screen!
            </p>
            
            <div className="flex gap-2">
              <button
                onClick={handleInstall}
                className="bg-white text-red-600 px-3 py-2 rounded-lg text-xs font-bold flex items-center gap-2 hover:bg-white/90 transition-all duration-300"
                style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}
              >
                {isInstallable ? <Download size={12} /> : <Plus size={12} />}
                Install
              </button>
              
              <button
                onClick={() => setShowPrompt(false)}
                className="text-white/80 hover:text-white p-2"
              >
                <X size={16} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InstallPrompt;