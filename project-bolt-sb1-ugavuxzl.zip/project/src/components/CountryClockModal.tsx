import React, { useState } from 'react';
import { X, Globe, Clock, Search } from 'lucide-react';

interface CountryClockModalProps {
  isOpen: boolean;
  onClose: () => void;
  onCountrySelect: (country: string, timezone: string) => void;
  selectedCountry: string;
}

const CountryClockModal: React.FC<CountryClockModalProps> = ({ 
  isOpen, 
  onClose, 
  onCountrySelect, 
  selectedCountry 
}) => {
  const [searchTerm, setSearchTerm] = useState('');

  if (!isOpen) return null;

  const countries = [
    { name: 'India', timezone: 'Asia/Kolkata', flag: '🇮🇳', popular: true },
    { name: 'United States', timezone: 'America/New_York', flag: '🇺🇸', popular: true },
    { name: 'United Kingdom', timezone: 'Europe/London', flag: '🇬🇧', popular: true },
    { name: 'Canada', timezone: 'America/Toronto', flag: '🇨🇦', popular: true },
    { name: 'Australia', timezone: 'Australia/Sydney', flag: '🇦🇺', popular: true },
    { name: 'Germany', timezone: 'Europe/Berlin', flag: '🇩🇪' },
    { name: 'France', timezone: 'Europe/Paris', flag: '🇫🇷' },
    { name: 'Japan', timezone: 'Asia/Tokyo', flag: '🇯🇵' },
    { name: 'China', timezone: 'Asia/Shanghai', flag: '🇨🇳' },
    { name: 'Brazil', timezone: 'America/Sao_Paulo', flag: '🇧🇷' },
    { name: 'Russia', timezone: 'Europe/Moscow', flag: '🇷🇺' },
    { name: 'South Africa', timezone: 'Africa/Johannesburg', flag: '🇿🇦' },
    { name: 'Mexico', timezone: 'America/Mexico_City', flag: '🇲🇽' },
    { name: 'Argentina', timezone: 'America/Argentina/Buenos_Aires', flag: '🇦🇷' },
    { name: 'Italy', timezone: 'Europe/Rome', flag: '🇮🇹' },
    { name: 'Spain', timezone: 'Europe/Madrid', flag: '🇪🇸' },
    { name: 'Netherlands', timezone: 'Europe/Amsterdam', flag: '🇳🇱' },
    { name: 'Sweden', timezone: 'Europe/Stockholm', flag: '🇸🇪' },
    { name: 'Norway', timezone: 'Europe/Oslo', flag: '🇳🇴' },
    { name: 'Denmark', timezone: 'Europe/Copenhagen', flag: '🇩🇰' },
    { name: 'Finland', timezone: 'Europe/Helsinki', flag: '🇫🇮' },
    { name: 'Poland', timezone: 'Europe/Warsaw', flag: '🇵🇱' },
    { name: 'Turkey', timezone: 'Europe/Istanbul', flag: '🇹🇷' },
    { name: 'Egypt', timezone: 'Africa/Cairo', flag: '🇪🇬' },
    { name: 'UAE', timezone: 'Asia/Dubai', flag: '🇦🇪' },
    { name: 'Saudi Arabia', timezone: 'Asia/Riyadh', flag: '🇸🇦' },
    { name: 'Singapore', timezone: 'Asia/Singapore', flag: '🇸🇬' },
    { name: 'Malaysia', timezone: 'Asia/Kuala_Lumpur', flag: '🇲🇾' },
    { name: 'Thailand', timezone: 'Asia/Bangkok', flag: '🇹🇭' },
    { name: 'Philippines', timezone: 'Asia/Manila', flag: '🇵🇭' },
    { name: 'Indonesia', timezone: 'Asia/Jakarta', flag: '🇮🇩' },
    { name: 'Vietnam', timezone: 'Asia/Ho_Chi_Minh', flag: '🇻🇳' },
    { name: 'South Korea', timezone: 'Asia/Seoul', flag: '🇰🇷' },
    { name: 'Bangladesh', timezone: 'Asia/Dhaka', flag: '🇧🇩' },
    { name: 'Pakistan', timezone: 'Asia/Karachi', flag: '🇵🇰' },
    { name: 'Sri Lanka', timezone: 'Asia/Colombo', flag: '🇱🇰' },
    { name: 'Nepal', timezone: 'Asia/Kathmandu', flag: '🇳🇵' },
    { name: 'New Zealand', timezone: 'Pacific/Auckland', flag: '🇳🇿' }
  ];

  const filteredCountries = countries.filter(country =>
    country.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const popularCountries = filteredCountries.filter(country => country.popular);
  const otherCountries = filteredCountries.filter(country => !country.popular);

  const getCurrentTime = (timezone: string) => {
    return new Date().toLocaleTimeString('en-US', {
      timeZone: timezone,
      hour12: true,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const handleCountryClick = (country: any) => {
    onCountrySelect(country.name, country.timezone);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-br from-black/90 to-blue-900/20 border border-blue-500/30 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-3">
              <Globe className="text-blue-400" size={32} />
              <h2 className="text-3xl font-bold text-white" style={{ fontFamily: 'Orbitron, monospace' }}>
                Select Your Country
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-blue-300 transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          {/* Search */}
          <div className="mb-6">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/60" size={20} />
              <input
                type="text"
                placeholder="Search countries..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full pl-10 pr-4 py-3 bg-black/70 border border-blue-500/50 rounded-lg text-white placeholder-gray-400 focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20 transition-all duration-300"
                style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}
              />
            </div>
          </div>

          {/* Popular Countries */}
          {popularCountries.length > 0 && (
            <div className="mb-8">
              <h3 className="text-xl font-bold text-white mb-4" style={{ fontFamily: 'Orbitron, monospace' }}>
                Popular Countries
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {popularCountries.map((country, index) => (
                  <button
                    key={index}
                    onClick={() => handleCountryClick(country)}
                    className={`bg-black/50 border rounded-xl p-4 transition-all duration-300 transform hover:scale-105 text-left ${
                      selectedCountry === country.name 
                        ? 'border-green-500 ring-2 ring-green-500/20 bg-green-900/20' 
                        : 'border-white/20 hover:border-blue-500'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <span className="text-2xl">{country.flag}</span>
                        <div>
                          <h4 className="text-white font-bold text-sm" style={{ fontFamily: 'Orbitron, monospace' }}>
                            {country.name}
                          </h4>
                          <p className="text-white/60 text-xs" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '8px' }}>
                            {country.timezone}
                          </p>
                        </div>
                      </div>
                      <div className="text-right">
                        <div className="flex items-center gap-1 mb-1">
                          <Clock size={12} className="text-blue-400" />
                          <span className="text-blue-300 text-sm font-bold" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}>
                            {getCurrentTime(country.timezone)}
                          </span>
                        </div>
                        {selectedCountry === country.name && (
                          <span className="text-green-400 text-xs" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '8px' }}>
                            SELECTED
                          </span>
                        )}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Other Countries */}
          {otherCountries.length > 0 && (
            <div>
              <h3 className="text-xl font-bold text-white mb-4" style={{ fontFamily: 'Orbitron, monospace' }}>
                All Countries
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {otherCountries.map((country, index) => (
                  <button
                    key={index}
                    onClick={() => handleCountryClick(country)}
                    className={`bg-black/50 border rounded-lg p-3 transition-all duration-300 transform hover:scale-105 text-left ${
                      selectedCountry === country.name 
                        ? 'border-green-500 ring-2 ring-green-500/20 bg-green-900/20' 
                        : 'border-white/20 hover:border-blue-500'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <span className="text-lg">{country.flag}</span>
                        <div>
                          <h4 className="text-white font-bold text-xs" style={{ fontFamily: 'Orbitron, monospace' }}>
                            {country.name}
                          </h4>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-blue-300 text-xs font-bold" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '8px' }}>
                          {getCurrentTime(country.timezone)}
                        </span>
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}

          <div className="mt-8 bg-green-900/30 border border-green-500/50 rounded-lg p-4">
            <p className="text-green-300 text-sm font-bold mb-2">Why Select Your Country?</p>
            <ul className="text-green-200 text-xs space-y-1">
              <li>• See real-time clock in your local timezone</li>
              <li>• Perfect timing for signal investments</li>
              <li>• Synchronized with your local market hours</li>
              <li>• Better planning for optimal betting times</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CountryClockModal;