import React, { useState, useEffect } from 'react';
import { Plane, Download, Star, Users, TrendingUp, Shield, Smartphone, Mail, MessageCircle } from 'lucide-react';

interface WelcomeScreenProps {
  onProceed: () => void;
}

const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onProceed }) => {
  const [displayText, setDisplayText] = useState('');
  const [showContent, setShowContent] = useState(false);
  const fullText = "Predict Aviator Game Outcomes with High Accuracy";

  useEffect(() => {
    let index = 0;
    const typeInterval = setInterval(() => {
      if (index < fullText.length) {
        setDisplayText(fullText.slice(0, index + 1));
        index++;
      } else {
        clearInterval(typeInterval);
        setTimeout(() => {
          setShowContent(true);
        }, 500);
      }
    }, 80);

    return () => clearInterval(typeInterval);
  }, []);

  const features = [
    { icon: <TrendingUp size={24} />, title: "5 Free Daily", desc: "Get 5 accurate signals every day for free" },
    { icon: <Shield size={24} />, title: "Secure & Safe", desc: "Your data is protected with enterprise-grade security" },
    { icon: <Smartphone size={24} />, title: "Mobile Optimized", desc: "Works perfectly on all devices and platforms" },
    { icon: <Users size={24} />, title: "10,000+ Users", desc: "Trusted by thousands of successful players" }
  ];

  const platforms = [
    "Fastwin", "1xBet", "Parimatch", "Betway", "Melbet", "1Win", "Mostbet", "Betano", "Dafabet", "BC.Game"
  ];

  const testimonials = [
    { name: "Rajesh K.", rating: 5, text: "Amazing accuracy! Made ₹5000 in first week." },
    { name: "Priya S.", rating: 5, text: "Best aviator predictor I've ever used. Highly recommended!" },
    { name: "Amit P.", rating: 5, text: "Works perfectly with Fastwin. Great support team too." }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-red-800 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-transparent via-white to-transparent transform -skew-y-12 animate-pulse"></div>
        <div className="absolute top-1/4 left-0 w-full h-px bg-white opacity-30 animate-pulse"></div>
        <div className="absolute top-1/2 left-0 w-full h-px bg-white opacity-30 animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-3/4 left-0 w-full h-px bg-white opacity-30 animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Floating planes */}
      <div className="absolute top-10 right-10 text-white opacity-20 animate-bounce">
        <Plane size={40} />
      </div>
      <div className="absolute bottom-10 left-10 text-white opacity-20 animate-bounce" style={{ animationDelay: '1s' }}>
        <Plane size={30} />
      </div>

      <div className="relative z-10 px-4 py-8">
        {/* Hero Section */}
        <div className="text-center mb-16 max-w-6xl mx-auto">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold text-white leading-tight drop-shadow-[0_0_20px_rgba(255,255,255,0.3)] mb-6"
              style={{ fontFamily: 'Orbitron, monospace', minHeight: '120px' }}>
            {displayText}
            <span className="animate-pulse">|</span>
          </h1>
          
          {showContent && (
            <div className="animate-fade-in">
              <p className="text-xl md:text-2xl text-red-300 mb-4" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '16px' }}>
                5 Free Signals Daily + Premium Plans Available
              </p>
              
              <p className="text-lg text-white/80 mb-8 max-w-3xl mx-auto leading-relaxed">
                Start with 5 free signals every day! Our advanced AI analyzes game patterns in real-time to provide 
                you with highly accurate predictions. Upgrade to premium for unlimited signals and advanced features.
              </p>

              <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
                <button
                  onClick={onProceed}
                  className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold py-4 px-8 rounded-2xl transition-all duration-300 transform hover:scale-105 shadow-lg hover:shadow-red-500/25 flex items-center justify-center gap-3"
                  style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '16px' }}
                >
                  <Plane size={24} />
                  START PREDICTING
                </button>
                
                <button
                  onClick={() => window.open('#download', '_self')}
                  className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold py-4 px-8 rounded-2xl transition-all duration-300 transform hover:scale-105 shadow-lg flex items-center justify-center gap-3"
                  style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '16px' }}
                >
                  <Download size={24} />
                  DOWNLOAD APP
                </button>
              </div>
            </div>
          )}
        </div>

        {showContent && (
          <div className="animate-fade-in">
            {/* Features Section */}
            <div className="max-w-6xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-12" style={{ fontFamily: 'Orbitron, monospace' }}>
                Why Choose Our Predictor?
              </h2>
              
              <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
                {features.map((feature, index) => (
                  <div key={index} className="bg-black/50 backdrop-blur-sm border border-white/20 rounded-xl p-6 text-center hover:border-red-500/50 transition-all duration-300">
                    <div className="text-red-400 mb-4 flex justify-center">
                      {feature.icon}
                    </div>
                    <h3 className="text-white font-bold mb-2" style={{ fontFamily: 'Orbitron, monospace' }}>
                      {feature.title}
                    </h3>
                    <p className="text-white/70 text-sm">{feature.desc}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Supported Platforms */}
            <div className="max-w-6xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-12" style={{ fontFamily: 'Orbitron, monospace' }}>
                Supported Platforms
              </h2>
              
              <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                {platforms.map((platform, index) => (
                  <div key={index} className="bg-gradient-to-r from-red-600/20 to-red-700/20 border border-red-500/30 rounded-lg p-4 text-center">
                    <span className="text-white font-bold" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}>
                      {platform}
                    </span>
                  </div>
                ))}
              </div>
            </div>

            {/* Testimonials */}
            <div className="max-w-6xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-12" style={{ fontFamily: 'Orbitron, monospace' }}>
                What Our Users Say
              </h2>
              
              <div className="grid md:grid-cols-3 gap-6">
                {testimonials.map((testimonial, index) => (
                  <div key={index} className="bg-black/50 backdrop-blur-sm border border-white/20 rounded-xl p-6">
                    <div className="flex items-center mb-4">
                      {[...Array(testimonial.rating)].map((_, i) => (
                        <Star key={i} size={16} className="text-yellow-400 fill-current" />
                      ))}
                    </div>
                    <p className="text-white/80 mb-4 italic">"{testimonial.text}"</p>
                    <p className="text-red-300 font-bold" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}>
                      - {testimonial.name}
                    </p>
                  </div>
                ))}
              </div>
            </div>

            {/* Download Section */}
            <div id="download" className="max-w-4xl mx-auto mb-16 bg-gradient-to-r from-green-900/30 to-blue-900/30 border border-green-500/30 rounded-2xl p-8">
              <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-8" style={{ fontFamily: 'Orbitron, monospace' }}>
                Download Our App
              </h2>
              
              <div className="text-center mb-8">
                <p className="text-white/80 mb-6 text-lg">
                  Get the mobile app for the best experience. Available for Android devices.
                </p>
                
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <button
                    onClick={() => alert('APK download will be available soon. Use web version for now.')}
                    className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold py-4 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-3"
                    style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '14px' }}
                  >
                    <Download size={20} />
                    Download APK
                  </button>
                  
                  <button
                    onClick={onProceed}
                    className="bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold py-4 px-8 rounded-xl transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-3"
                    style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '14px' }}
                  >
                    <Smartphone size={20} />
                    Use Web Version
                  </button>
                </div>
              </div>
              
              <div className="bg-black/30 rounded-lg p-4">
                <h3 className="text-white font-bold mb-3" style={{ fontFamily: 'Orbitron, monospace' }}>
                  Installation Instructions:
                </h3>
                <ol className="text-white/80 text-sm space-y-2">
                  <li>1. Download the APK file to your Android device</li>
                  <li>2. Enable "Unknown Sources" in your device settings</li>
                  <li>3. Install the APK file</li>
                  <li>4. Open the app and start predicting!</li>
                </ol>
              </div>
            </div>

            {/* Contact Section */}
            <div className="max-w-4xl mx-auto mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-12" style={{ fontFamily: 'Orbitron, monospace' }}>
                Contact & Support
              </h2>
              
              <div className="grid md:grid-cols-2 gap-8">
                <div className="bg-black/50 backdrop-blur-sm border border-white/20 rounded-xl p-6">
                  <h3 className="text-white font-bold mb-4 flex items-center gap-3" style={{ fontFamily: 'Orbitron, monospace' }}>
                    <Mail className="text-blue-400" size={24} />
                    Email Support
                  </h3>
                  <p className="text-white/80 mb-4">
                    For technical support, business inquiries, or app purchases:
                  </p>
                  <a 
                    href="mailto:chetanagarwalla06@gmail.com"
                    className="text-blue-400 hover:text-blue-300 font-bold break-all"
                  >
                    chetanagarwalla06@gmail.com
                  </a>
                </div>
                
                <div className="bg-black/50 backdrop-blur-sm border border-white/20 rounded-xl p-6">
                  <h3 className="text-white font-bold mb-4 flex items-center gap-3" style={{ fontFamily: 'Orbitron, monospace' }}>
                    <MessageCircle className="text-green-400" size={24} />
                    Telegram Support
                  </h3>
                  <p className="text-white/80 mb-4">
                    Join our Telegram for instant support and updates:
                  </p>
                  <a 
                    href="https://t.me/aviatorpredictorXYZ100"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-green-400 hover:text-green-300 font-bold break-all"
                  >
                    @aviatorpredictorXYZ100
                  </a>
                </div>
              </div>
            </div>

            {/* Trust Signals */}
            <div className="max-w-6xl mx-auto mb-16">
              <div className="bg-gradient-to-r from-yellow-900/30 to-orange-900/30 border border-yellow-500/30 rounded-2xl p-8">
                <h2 className="text-3xl md:text-4xl font-bold text-white text-center mb-8" style={{ fontFamily: 'Orbitron, monospace' }}>
                  Trusted by Thousands
                </h2>
                
                <div className="grid md:grid-cols-4 gap-6 text-center">
                  <div>
                    <div className="text-4xl font-bold text-yellow-400 mb-2" style={{ fontFamily: 'Press Start 2P, monospace' }}>
                      10,000+
                    </div>
                    <div className="text-white/80">Active Users</div>
                  </div>
                  <div>
                    <div className="text-4xl font-bold text-green-400 mb-2" style={{ fontFamily: 'Press Start 2P, monospace' }}>
                      99%
                    </div>
                    <div className="text-white/80">Accuracy Rate</div>
                  </div>
                  <div>
                    <div className="text-4xl font-bold text-blue-400 mb-2" style={{ fontFamily: 'Press Start 2P, monospace' }}>
                      24/7
                    </div>
                    <div className="text-white/80">Support</div>
                  </div>
                  <div>
                    <div className="text-4xl font-bold text-purple-400 mb-2" style={{ fontFamily: 'Press Start 2P, monospace' }}>
                      100%
                    </div>
                    <div className="text-white/80">Secure</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Legal Notice */}
            <div className="max-w-4xl mx-auto text-center">
              <div className="bg-red-900/30 border border-red-500/50 rounded-xl p-6">
                <h3 className="text-white font-bold mb-4" style={{ fontFamily: 'Orbitron, monospace' }}>
                  Important Disclaimer
                </h3>
                <p className="text-white/80 text-sm mb-4">
                  This app is for entertainment purposes only. Gambling involves risk and should be done responsibly. 
                  Please ensure compliance with your local laws and regulations.
                </p>
                <div className="flex flex-col sm:flex-row gap-4 justify-center text-sm">
                  <button
                    onClick={() => alert('Privacy Policy will be displayed here')}
                    className="text-blue-400 hover:text-blue-300 underline"
                  >
                    Privacy Policy
                  </button>
                  <button
                    onClick={() => alert('Terms of Service will be displayed here')}
                    className="text-blue-400 hover:text-blue-300 underline"
                  >
                    Terms of Service
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default WelcomeScreen;