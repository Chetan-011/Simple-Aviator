import React, { useState, useEffect } from 'react';
import { Lock, Plane, Menu, X, Youtube, Shield } from 'lucide-react';

interface AccessCodeScreenProps {
  onAccessGranted: () => void;
  onGetCode: () => void;
}

const AccessCodeScreen: React.FC<AccessCodeScreenProps> = ({ onAccessGranted, onGetCode }) => {
  const [inputCode, setInputCode] = useState('');
  const [error, setError] = useState('');
  const [displayValue, setDisplayValue] = useState('');
  const [showMenu, setShowMenu] = useState(false);
  const [captchaQuestion, setCaptchaQuestion] = useState('');
  const [captchaAnswer, setCaptchaAnswer] = useState(0);
  const [userCaptchaAnswer, setUserCaptchaAnswer] = useState('');
  const [captchaError, setCaptchaError] = useState('');
  
  // Base64 encoded access code
  const correctCode = btoa('2ib9tcc11vya');
  const actualCode = '2ib9tcc11vya';

  // Generate captcha on component mount
  useEffect(() => {
    generateCaptcha();
  }, []);

  const generateCaptcha = () => {
    const num1 = Math.floor(Math.random() * 5) + 1; // 1-5
    const num2 = Math.floor(Math.random() * 5) + 1; // 1-5
    const operations = ['+'];
    const operation = operations[0]; // Only addition
    
    let answer: number;
    let question: string;
    
    switch (operation) {
      case '+':
        answer = num1 + num2;
        question = `${num1} + ${num2}`;
        break;
      default:
        answer = num1 + num2;
        question = `${num1} + ${num2}`;
    }
    
    setCaptchaQuestion(question);
    setCaptchaAnswer(answer);
    setUserCaptchaAnswer('');
    setCaptchaError('');
  };

  useEffect(() => {
    if (inputCode.length === 0) {
      setDisplayValue('');
      return;
    }

    // Show the latest character, then convert previous ones to dots after 0.75s
    const timeouts: NodeJS.Timeout[] = [];
    
    // Set display to show current input
    setDisplayValue(inputCode);
    
    // For each character except the last one, set a timeout to convert to dot
    for (let i = 0; i < inputCode.length - 1; i++) {
      const timeout = setTimeout(() => {
        setDisplayValue(prev => {
          const chars = prev.split('');
          chars[i] = '•';
          return chars.join('');
        });
      }, 750);
      timeouts.push(timeout);
    }

    // Convert the last character to dot after 0.75s
    if (inputCode.length > 0) {
      const lastTimeout = setTimeout(() => {
        setDisplayValue(prev => {
          const chars = prev.split('');
          chars[inputCode.length - 1] = '•';
          return chars.join('');
        });
      }, 750);
      timeouts.push(lastTimeout);
    }

    return () => {
      timeouts.forEach(timeout => clearTimeout(timeout));
    };
  }, [inputCode]);

  const handleSubmit = () => {
    // First verify captcha
    const userNum = parseInt(userCaptchaAnswer);
    if (userNum !== captchaAnswer) {
      setCaptchaError('Incorrect captcha. Please try again.');
      generateCaptcha();
      return;
    }
    
    setCaptchaError('');
    
    // Then verify access code
    if (inputCode === actualCode) {
      onAccessGranted();
    } else {
      setError('The Access Code is Wrong, Try Again');
      setInputCode('');
      setDisplayValue('');
      setTimeout(() => setError(''), 3000);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter') {
      handleSubmit();
    }
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setInputCode(e.target.value);
  };

  const handleYouTubeRedirect = () => {
    window.open('https://youtube.com/@cyber_crushers?si=h6p4P1w6-tCRFU7q', '_blank');
    setShowMenu(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-red-800 flex items-center justify-center relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-0 left-0 w-full h-full bg-gradient-to-r from-transparent via-white to-transparent transform -skew-y-12 animate-pulse"></div>
        <div className="absolute top-1/4 left-0 w-full h-px bg-white opacity-30 animate-pulse"></div>
        <div className="absolute top-1/2 left-0 w-full h-px bg-white opacity-30 animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-3/4 left-0 w-full h-px bg-white opacity-30 animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Floating planes */}
      <div className="absolute top-10 right-10 text-white opacity-20 animate-bounce">
        <Plane size={40} />
      </div>
      <div className="absolute bottom-10 left-10 text-white opacity-20 animate-bounce" style={{ animationDelay: '1s' }}>
        <Plane size={30} />
      </div>

      {/* Top-left menu button */}
      <div className="absolute top-6 left-6 z-20">
        <button
          onClick={() => setShowMenu(!showMenu)}
          className="bg-black/50 backdrop-blur-sm border border-red-500/30 rounded-lg p-3 text-white hover:bg-black/70 transition-all duration-300"
        >
          {showMenu ? <X size={20} /> : <Menu size={20} />}
        </button>
        
        {/* Dropdown menu */}
        {showMenu && (
          <div className="absolute top-16 left-0 bg-black/80 backdrop-blur-sm border border-red-500/30 rounded-lg p-4 min-w-[250px] shadow-2xl">
            <div className="space-y-2">
              <button
                onClick={() => {
                  onGetCode();
                  setShowMenu(false);
                }}
                className="w-full text-left text-white hover:text-red-300 py-3 px-3 rounded hover:bg-red-500/20 transition-all duration-300 flex items-center gap-3"
                style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}
              >
                <span>📝</span>
                Get the Code (Writing Task)
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="bg-black/50 backdrop-blur-sm border border-red-500/30 rounded-2xl p-8 shadow-2xl max-w-md w-full mx-4">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="bg-red-600 p-4 rounded-full shadow-lg">
              <Lock className="text-white" size={32} />
            </div>
          </div>
          <h2 className="text-3xl font-bold text-white mb-2" style={{ fontFamily: 'Orbitron, monospace' }}>
            AVIATOR ACCESS
          </h2>
          <p className="text-red-300 text-sm">Enter the access code to proceed</p>
          <div className="mt-3 bg-green-900/30 border border-green-500/50 rounded-lg p-3">
            <p className="text-green-300 text-xs font-bold mb-1">🎉 Free Plan Available!</p>
            <p className="text-green-200 text-xs">Get 5 accurate signals daily - no payment required!</p>
          </div>
        </div>

        <div className="space-y-6">
          <div>
            <label className="block text-white font-medium mb-2 text-sm">Access Code</label>
            <div className="relative">
              <input
                type="text"
                value={inputCode}
                onChange={handleInputChange}
                onKeyPress={handleKeyPress}
                className="w-full px-4 py-3 bg-black/70 border border-red-500/50 rounded-lg text-transparent placeholder-gray-400 focus:outline-none focus:border-red-400 focus:ring-2 focus:ring-red-400/20 transition-all duration-300 caret-white"
                placeholder="Enter access code..."
                style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}
              />
              <div 
                className="absolute inset-0 px-4 py-3 pointer-events-none text-white"
                style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}
              >
                {displayValue}
              </div>
            </div>
          </div>

          {error && (
            <div className="bg-red-900/50 border border-red-500 rounded-lg p-3 text-red-200 text-sm text-center animate-pulse">
              {error}
            </div>
          )}

          {/* Captcha Section */}
          <div className="bg-black/50 border border-blue-500/30 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-3">
              <Shield className="text-blue-400" size={16} />
              <span className="text-blue-300 font-bold text-sm" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}>
                Human Verification
              </span>
            </div>
            
            <div className="text-center mb-3">
              <div className="text-xl font-bold text-blue-400 mb-2" style={{ fontFamily: 'Press Start 2P, monospace' }}>
                {captchaQuestion} = ?
              </div>
              
              <input
                type="number"
                value={userCaptchaAnswer}
                onChange={(e) => setUserCaptchaAnswer(e.target.value)}
                className="w-full px-3 py-2 bg-black/70 border border-blue-500/50 rounded-lg text-white text-center font-bold focus:outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20 transition-all duration-300"
                placeholder="Your answer"
                style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}
              />
            </div>

            {captchaError && (
              <div className="bg-red-900/50 border border-red-500 rounded-lg p-2 text-red-200 text-xs text-center mb-3">
                {captchaError}
              </div>
            )}
            
            <button
              onClick={generateCaptcha}
              className="w-full bg-gray-600 hover:bg-gray-700 text-white font-bold py-2 px-3 rounded-lg transition-all duration-300 text-xs"
              style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '8px' }}
            >
              New Question
            </button>
          </div>

          <button
            onClick={handleSubmit}
            className="w-full bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:shadow-red-500/25 flex items-center justify-center gap-2"
            style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '14px' }}
          >
            <span>🔒</span>
            PROCEED
          </button>
        </div>
      </div>
    </div>
  );
};

export default AccessCodeScreen;