import React from 'react';
import { X, TrendingUp, Download, Share2, BarChart3 } from 'lucide-react';

interface AnalyticsModalProps {
  isOpen: boolean;
  onClose: () => void;
  recentSignals: string[];
  totalSignalCount: number;
  dailySignalCount: number;
}

const AnalyticsModal: React.FC<AnalyticsModalProps> = ({ 
  isOpen, 
  onClose, 
  recentSignals, 
  totalSignalCount, 
  dailySignalCount 
}) => {
  if (!isOpen) return null;

  const getSignalColor = (value: number) => {
    if (value >= 1.00 && value <= 1.99) return 'text-red-300';
    if (value >= 2.00 && value <= 4.99) return 'text-yellow-300';
    if (value >= 5.00 && value <= 9.99) return 'text-green-300';
    if (value >= 10.00 && value <= 49.99) return 'text-purple-300';
    if (value >= 50.00) return 'text-transparent bg-gradient-to-r from-red-500 via-yellow-500 via-green-500 via-blue-500 to-purple-500 bg-clip-text';
    return 'text-white';
  };

  const getSignalCategory = (value: number) => {
    if (value >= 1.00 && value <= 1.99) return 'Low Risk';
    if (value >= 2.00 && value <= 4.99) return 'Medium Risk';
    if (value >= 5.00 && value <= 9.99) return 'High Value';
    if (value >= 10.00 && value <= 49.99) return 'Super High';
    if (value >= 50.00) return 'Mega Win';
    return 'Unknown';
  };

  const calculateStats = () => {
    const signals = recentSignals.map(s => parseFloat(s.replace('X', '')));
    const avgSignal = signals.length > 0 ? (signals.reduce((a, b) => a + b, 0) / signals.length).toFixed(2) : '0.00';
    const maxSignal = signals.length > 0 ? Math.max(...signals).toFixed(2) : '0.00';
    const highValueCount = signals.filter(s => s >= 5.0).length;
    
    return { avgSignal, maxSignal, highValueCount };
  };

  const { avgSignal, maxSignal, highValueCount } = calculateStats();

  const downloadAnalytics = () => {
    const data = {
      totalSignals: totalSignalCount,
      dailySignals: dailySignalCount,
      recentSignals: recentSignals,
      averageSignal: avgSignal,
      maxSignal: maxSignal,
      highValueSignals: highValueCount,
      exportDate: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `aviator-signals-analytics-${new Date().toISOString().split('T')[0]}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  const shareAnalytics = async () => {
    const shareText = `🚀 My Aviator Signals Analytics:\n\n📊 Total Signals: ${totalSignalCount}\n📈 Today's Signals: ${dailySignalCount}\n🎯 Average Signal: ${avgSignal}X\n🏆 Best Signal: ${maxSignal}X\n💎 High Value Signals: ${highValueCount}\n\nGet your signals at Aviator Signals AI!`;
    
    if (navigator.share) {
      try {
        await navigator.share({
          title: 'Aviator Signals Analytics',
          text: shareText
        });
      } catch (err) {
        console.log('Error sharing:', err);
      }
    } else {
      // Fallback to clipboard
      navigator.clipboard.writeText(shareText);
      alert('Analytics copied to clipboard!');
    }
  };

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-br from-black/90 to-blue-900/20 border border-blue-500/30 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-3">
              <BarChart3 className="text-blue-400" size={32} />
              <h2 className="text-3xl font-bold text-white" style={{ fontFamily: 'Orbitron, monospace' }}>
                Signal Analytics
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-blue-300 transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          {/* Stats Overview */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-black/50 border border-blue-500/30 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-blue-400 mb-1">{totalSignalCount}</div>
              <div className="text-white/60 text-sm">Total Signals</div>
            </div>
            <div className="bg-black/50 border border-green-500/30 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-green-400 mb-1">{dailySignalCount}</div>
              <div className="text-white/60 text-sm">Today's Signals</div>
            </div>
            <div className="bg-black/50 border border-yellow-500/30 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-yellow-400 mb-1">{avgSignal}X</div>
              <div className="text-white/60 text-sm">Average Signal</div>
            </div>
            <div className="bg-black/50 border border-purple-500/30 rounded-lg p-4 text-center">
              <div className="text-2xl font-bold text-purple-400 mb-1">{maxSignal}X</div>
              <div className="text-white/60 text-sm">Best Signal</div>
            </div>
          </div>

          {/* Recent Signals Table */}
          <div className="bg-black/50 border border-white/20 rounded-xl p-6 mb-6">
            <h3 className="text-xl font-bold text-white mb-4" style={{ fontFamily: 'Orbitron, monospace' }}>
              Last 10 Signals
            </h3>
            
            {recentSignals.length > 0 ? (
              <div className="space-y-3">
                <div className="grid grid-cols-4 gap-4 text-white/60 text-sm font-bold border-b border-white/20 pb-2">
                  <div>#</div>
                  <div>Signal</div>
                  <div>Category</div>
                  <div>Status</div>
                </div>
                {recentSignals.slice(0, 10).map((signal, index) => {
                  const value = parseFloat(signal.replace('X', ''));
                  const signalNumber = totalSignalCount - index;
                  return (
                    <div key={index} className="grid grid-cols-4 gap-4 items-center py-2 border-b border-white/10">
                      <div className="text-white/60 text-sm">#{signalNumber}</div>
                      <div className={`${getSignalColor(value)} font-bold text-lg`}>
                        {signal}
                      </div>
                      <div className="text-white/80 text-sm">
                        {getSignalCategory(value)}
                      </div>
                      <div className="flex items-center gap-1">
                        <div className={`w-2 h-2 rounded-full ${value >= 5.0 ? 'bg-green-400' : value >= 2.0 ? 'bg-yellow-400' : 'bg-red-400'}`}></div>
                        <span className="text-white/60 text-xs">
                          {value >= 5.0 ? 'High' : value >= 2.0 ? 'Med' : 'Low'}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="text-center py-8">
                <TrendingUp className="text-white/40 mx-auto mb-4" size={48} />
                <p className="text-white/60">No signals generated yet</p>
                <p className="text-white/40 text-sm">Start generating signals to see analytics</p>
              </div>
            )}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row gap-4">
            <button
              onClick={downloadAnalytics}
              className="flex-1 bg-gradient-to-r from-blue-600 to-blue-700 hover:from-blue-700 hover:to-blue-800 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2"
              style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}
            >
              <Download size={16} />
              Download Data
            </button>
            
            <button
              onClick={shareAnalytics}
              className="flex-1 bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105 flex items-center justify-center gap-2"
              style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}
            >
              <Share2 size={16} />
              Share Results
            </button>
          </div>

          <div className="mt-6 text-center">
            <p className="text-gray-400 text-sm">
              Analytics updated in real-time • Export your data anytime
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsModal;