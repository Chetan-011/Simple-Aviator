import React, { useState } from 'react';
import { ArrowLeft, CheckCircle, XCircle } from 'lucide-react';
import { generateRandomTask } from '../utils/taskGenerator';

interface GetCodeScreenProps {
  onBack: () => void;
}

const GetCodeScreen: React.FC<GetCodeScreenProps> = ({ onBack }) => {
  const [userText, setUserText] = useState('');
  const [showResult, setShowResult] = useState(false);
  const [mistakes, setMistakes] = useState(0);
  const [showCode, setShowCode] = useState(false);
  const [currentTask, setCurrentTask] = useState(generateRandomTask());

  const regenerateTask = () => {
    setCurrentTask(generateRandomTask());
    setUserText('');
    setShowResult(false);
    setShowCode(false);
    setMistakes(0);
  };

  const checkMistakes = () => {
    const originalWords = currentTask.story.toLowerCase().replace(/[^\w\s]/g, '').split(/\s+/);
    const userWords = userText.toLowerCase().replace(/[^\w\s]/g, '').split(/\s+/);
    
    let mistakeCount = 0;
    const maxLength = Math.max(originalWords.length, userWords.length);
    
    for (let i = 0; i < maxLength; i++) {
      if (originalWords[i] !== userWords[i]) {
        mistakeCount++;
      }
    }
    
    setMistakes(mistakeCount);
    setShowResult(true);
  };

  const handleGetCode = () => {
    setShowCode(true);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-red-800 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/4 left-0 w-full h-px bg-white animate-pulse"></div>
        <div className="absolute top-1/2 left-0 w-full h-px bg-white animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-3/4 left-0 w-full h-px bg-white animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      {/* Back button */}
      <div className="absolute top-6 left-6 z-10">
        <button
          onClick={onBack}
          className="bg-black/50 backdrop-blur-sm border border-red-500/30 rounded-lg p-3 text-white hover:bg-black/70 transition-all duration-300 flex items-center gap-2"
        >
          <ArrowLeft size={20} />
          <span style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}>Back</span>
        </button>
      </div>

      <div className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-8">
            <h2 className="text-4xl font-bold text-white mb-4" style={{ fontFamily: 'Orbitron, monospace' }}>
              GET ACCESS CODE
            </h2>
            <p className="text-red-300 text-lg" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '14px' }}>
              Complete the writing task to earn your code
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-8">
            {/* Image and Instructions */}
            <div className="bg-black/50 backdrop-blur-sm border border-red-500/30 rounded-2xl p-6">
              <img 
                src={currentTask.image} 
                alt="Story inspiration" 
                className="w-full h-64 object-cover rounded-lg mb-4"
              />
              <div className="text-white">
                <h3 className="text-xl font-bold mb-4" style={{ fontFamily: 'Orbitron, monospace' }}>
                  Task Instructions
                </h3>
                <p className="text-sm mb-4" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}>
                  Look at the image above and write the story shown below. You must have less than 5 mistakes to get the access code.
                </p>
                
                <button
                  onClick={regenerateTask}
                  className="mb-4 bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300"
                  style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}
                >
                  Get Different Task
                </button>
                
                <div className="bg-black/70 p-4 rounded-lg text-xs leading-relaxed" style={{ fontFamily: 'monospace' }}>
                  {currentTask.story}
                </div>
              </div>
            </div>

            {/* Writing Area */}
            <div className="bg-black/50 backdrop-blur-sm border border-red-500/30 rounded-2xl p-6">
              <h3 className="text-xl font-bold text-white mb-4" style={{ fontFamily: 'Orbitron, monospace' }}>
                Write Your Story
              </h3>
              
              <textarea
                value={userText}
                onChange={(e) => setUserText(e.target.value)}
                placeholder="Start typing the story here..."
                className="w-full h-64 bg-black/70 border border-red-500/50 rounded-lg p-4 text-white placeholder-gray-400 focus:outline-none focus:border-red-400 focus:ring-2 focus:ring-red-400/20 transition-all duration-300 resize-none text-sm"
                style={{ fontFamily: 'monospace' }}
              />

              <div className="mt-4 flex justify-between items-center">
                <span className="text-white/60 text-sm" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}>
                  Words: {userText.split(/\s+/).filter(word => word.length > 0).length}
                </span>
                
                {!showResult && (
                  <button
                    onClick={checkMistakes}
                    disabled={userText.trim().length < 50}
                    className="bg-gradient-to-r from-red-600 to-red-700 hover:from-red-700 hover:to-red-800 disabled:from-gray-600 disabled:to-gray-700 text-white font-bold py-2 px-4 rounded-lg transition-all duration-300 transform hover:scale-105 disabled:scale-100"
                    style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}
                  >
                    Check Story
                  </button>
                )}
              </div>

              {/* Results */}
              {showResult && (
                <div className="mt-6 p-4 rounded-lg border">
                  {mistakes <= 5 ? (
                    <div className="border-green-500 bg-green-900/30">
                      <div className="flex items-center gap-2 mb-3">
                        <CheckCircle className="text-green-400" size={24} />
                        <span className="text-green-400 font-bold" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}>
                          Great Job! {mistakes} mistakes found
                        </span>
                      </div>
                      
                      {!showCode ? (
                        <button
                          onClick={handleGetCode}
                          className="bg-gradient-to-r from-green-600 to-green-700 hover:from-green-700 hover:to-green-800 text-white font-bold py-3 px-6 rounded-lg transition-all duration-300 transform hover:scale-105"
                          style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '14px' }}
                        >
                          Get Access Code
                        </button>
                      ) : (
                        <div className="bg-black/70 p-4 rounded-lg">
                          <p className="text-white mb-2" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}>
                            Your Access Code:
                          </p>
                          <div className="flex items-center gap-2">
                            <code className="bg-red-600 text-white px-4 py-2 rounded font-bold text-lg">
                              2ib9tcc11vya
                            </code>
                            <button
                              onClick={() => copyToClipboard('2ib9tcc11vya')}
                              className="bg-gray-600 hover:bg-gray-700 text-white px-3 py-2 rounded text-sm transition-all duration-300"
                            >
                              Copy
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  ) : (
                    <div className="border-red-500 bg-red-900/30">
                      <div className="flex items-center gap-2">
                        <XCircle className="text-red-400" size={24} />
                        <span className="text-red-400 font-bold" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}>
                          Please check the mistakes in the paragraph ({mistakes} mistakes found)
                        </span>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default GetCodeScreen;