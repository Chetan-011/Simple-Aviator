import React from 'react';
import { X, FileText, AlertTriangle, Scale, Users } from 'lucide-react';

interface TermsOfServiceProps {
  isOpen: boolean;
  onClose: () => void;
}

const TermsOfService: React.FC<TermsOfServiceProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/80 backdrop-blur-sm z-50 flex items-center justify-center p-4">
      <div className="bg-gradient-to-br from-black/90 to-purple-900/20 border border-purple-500/30 rounded-2xl max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <div className="flex justify-between items-center mb-6">
            <div className="flex items-center gap-3">
              <FileText className="text-purple-400" size={32} />
              <h2 className="text-3xl font-bold text-white" style={{ fontFamily: 'Orbitron, monospace' }}>
                Terms of Service
              </h2>
            </div>
            <button
              onClick={onClose}
              className="text-white hover:text-purple-300 transition-colors"
            >
              <X size={24} />
            </button>
          </div>

          <div className="space-y-6 text-white">
            <div className="bg-black/50 border border-purple-500/30 rounded-lg p-4">
              <p className="text-purple-300 text-sm">
                <strong>Last Updated:</strong> January 2025
              </p>
              <p className="text-white/80 text-sm mt-2">
                By using Aviator Predictor, you agree to these Terms of Service. Please read them carefully.
              </p>
            </div>

            <div className="space-y-4">
              <div className="flex items-start gap-3">
                <Users className="text-blue-400 mt-1" size={20} />
                <div>
                  <h3 className="text-xl font-bold mb-2" style={{ fontFamily: 'Orbitron, monospace' }}>
                    Acceptance of Terms
                  </h3>
                  <ul className="text-white/80 space-y-2 text-sm">
                    <li>• By accessing our app, you agree to be bound by these terms</li>
                    <li>• You must be at least 18 years old to use this service</li>
                    <li>• You are responsible for compliance with local laws</li>
                    <li>• We reserve the right to modify these terms at any time</li>
                  </ul>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <Scale className="text-green-400 mt-1" size={20} />
                <div>
                  <h3 className="text-xl font-bold mb-2" style={{ fontFamily: 'Orbitron, monospace' }}>
                    Service Description
                  </h3>
                  <ul className="text-white/80 space-y-2 text-sm">
                    <li>• Aviator Predictor provides game pattern analysis and predictions</li>
                    <li>• Predictions are based on algorithms and historical data</li>
                    <li>• We do not guarantee the accuracy of predictions</li>
                    <li>• The service is for entertainment purposes only</li>
                    <li>• We are not responsible for any financial losses</li>
                  </ul>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <AlertTriangle className="text-yellow-400 mt-1" size={20} />
                <div>
                  <h3 className="text-xl font-bold mb-2" style={{ fontFamily: 'Orbitron, monospace' }}>
                    User Responsibilities
                  </h3>
                  <ul className="text-white/80 space-y-2 text-sm">
                    <li>• Use the service responsibly and legally</li>
                    <li>• Do not attempt to reverse engineer or hack the app</li>
                    <li>• Respect intellectual property rights</li>
                    <li>• Do not share your account credentials</li>
                    <li>• Report any bugs or security issues promptly</li>
                  </ul>
                </div>
              </div>

              <div className="bg-red-900/30 border border-red-500/50 rounded-lg p-4">
                <h3 className="text-red-300 font-bold mb-2">Gambling Disclaimer</h3>
                <ul className="text-red-200 text-sm space-y-1">
                  <li>• This app does not encourage gambling</li>
                  <li>• Gambling involves financial risk and can be addictive</li>
                  <li>• Please gamble responsibly and within your means</li>
                  <li>• Seek help if you have gambling problems</li>
                  <li>• We are not liable for any gambling-related losses</li>
                </ul>
              </div>

              <div className="bg-blue-900/30 border border-blue-500/50 rounded-lg p-4">
                <h3 className="text-blue-300 font-bold mb-2">Payment Terms</h3>
                <ul className="text-blue-200 text-sm space-y-1">
                  <li>• Subscription fees are charged in advance</li>
                  <li>• Refunds are provided according to our refund policy</li>
                  <li>• Prices may change with 30 days notice</li>
                  <li>• Payment processing is handled by third-party providers</li>
                  <li>• Subscription data is preserved permanently after purchase</li>
                </ul>
              </div>

              <div className="bg-purple-900/30 border border-purple-500/50 rounded-lg p-4">
                <h3 className="text-purple-300 font-bold mb-2">Intellectual Property</h3>
                <p className="text-purple-200 text-sm">
                  All content, algorithms, and software are proprietary to Aviator Predictor. 
                  Users are granted a limited license to use the service for personal, non-commercial purposes only.
                </p>
              </div>

              <div className="bg-gray-900/30 border border-gray-500/50 rounded-lg p-4">
                <h3 className="text-gray-300 font-bold mb-2">Limitation of Liability</h3>
                <p className="text-gray-200 text-sm">
                  We provide the service "as is" without warranties. We are not liable for any direct, indirect, 
                  incidental, or consequential damages arising from your use of the service.
                </p>
              </div>

              <div className="bg-green-900/30 border border-green-500/50 rounded-lg p-4">
                <h3 className="text-green-300 font-bold mb-2">Termination</h3>
                <ul className="text-green-200 text-sm space-y-1">
                  <li>• We may terminate accounts for violations of these terms</li>
                  <li>• You may cancel your subscription at any time</li>
                  <li>• Termination does not affect already processed payments</li>
                  <li>• Data may be retained according to our privacy policy</li>
                </ul>
              </div>
            </div>

            <div className="border-t border-white/20 pt-6">
              <h3 className="text-xl font-bold mb-4" style={{ fontFamily: 'Orbitron, monospace' }}>
                Contact Information
              </h3>
              <p className="text-white/80 mb-4">
                For questions about these Terms of Service, contact us:
              </p>
              <div className="space-y-2">
                <p className="text-blue-400">
                  <strong>Email:</strong> chetanagarwalla06@gmail.com
                </p>
                <p className="text-green-400">
                  <strong>Telegram:</strong> @aviatorpredictorXYZ100
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default TermsOfService;