import React, { useState } from 'react';
import { Gamepad2, ChevronRight, Zap, Target, Crown } from 'lucide-react';

interface PlatformSelectionScreenProps {
  onPlatformSelected: (platform: string) => void;
}

const PlatformSelectionScreen: React.FC<PlatformSelectionScreenProps> = ({ onPlatformSelected }) => {
  const [selectedPlatform, setSelectedPlatform] = useState<string>('');

  const platforms = [
    { name: '1xBet', logo: '🎯', color: 'from-blue-600 to-blue-700', popular: true },
    { name: 'Parimatch', logo: '⚡', color: 'from-yellow-600 to-yellow-700', popular: true },
    { name: 'Betway', logo: '🎲', color: 'from-green-600 to-green-700', popular: true },
    { name: 'Melbet', logo: '🔥', color: 'from-red-600 to-red-700' },
    { name: '1Win', logo: '🏆', color: 'from-purple-600 to-purple-700' },
    { name: 'Mostbet', logo: '💎', color: 'from-indigo-600 to-indigo-700' },
    { name: 'Betano', logo: '⭐', color: 'from-orange-600 to-orange-700' },
    { name: 'Dafabet', logo: '🎪', color: 'from-pink-600 to-pink-700' },
    { name: 'BC.Game', logo: '🚀', color: 'from-cyan-600 to-cyan-700' },
    { name: 'Stake.com', logo: '💰', color: 'from-emerald-600 to-emerald-700' },
    { name: 'Fairplay', logo: '⚖️', color: 'from-teal-600 to-teal-700' },
    { name: 'Rajabets', logo: '👑', color: 'from-amber-600 to-amber-700' },
    { name: 'Fun88', logo: '🎊', color: 'from-lime-600 to-lime-700' },
    { name: '22Bet', logo: '🎯', color: 'from-violet-600 to-violet-700' },
    { name: '91Club', logo: '🎮', color: 'from-rose-600 to-rose-700' },
    { name: 'LeonBet', logo: '🦁', color: 'from-yellow-600 to-orange-600' },
    { name: 'IndiBet', logo: '🇮🇳', color: 'from-orange-600 to-red-600' },
    { name: 'LeetWin', logo: '⚡', color: 'from-blue-600 to-purple-600' },
    { name: 'Sky247', logo: '☁️', color: 'from-sky-600 to-blue-600' },
    { name: 'BetTilt', logo: '🎰', color: 'from-gray-600 to-gray-700' }
  ];

  const handlePlatformClick = (platform: string) => {
    console.log('Platform clicked:', platform);
    // Directly navigate to signal generator when platform is clicked
    onPlatformSelected(platform);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-red-800 relative overflow-hidden">
      {/* Animated background */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-1/4 left-0 w-full h-px bg-white animate-pulse"></div>
        <div className="absolute top-1/2 left-0 w-full h-px bg-white animate-pulse" style={{ animationDelay: '1s' }}></div>
        <div className="absolute top-3/4 left-0 w-full h-px bg-white animate-pulse" style={{ animationDelay: '2s' }}></div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <div className="max-w-6xl mx-auto">
          {/* Header */}
          <div className="text-center mb-12">
            <div className="flex justify-center mb-6">
              <div className="bg-gradient-to-r from-red-600 to-red-700 p-4 rounded-full shadow-lg">
                <Target className="text-white" size={48} />
              </div>
            </div>
            <h2 className="text-4xl md:text-6xl font-bold text-white mb-4 drop-shadow-[0_0_20px_rgba(255,255,255,0.3)]" style={{ fontFamily: 'Orbitron, monospace' }}>
              SELECT PLATFORM
            </h2>
            <p className="text-red-300 text-lg mb-4" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '14px' }}>
              Choose your aviator gaming platform for accurate signals
            </p>
            <div className="bg-green-900/30 border border-green-500/50 rounded-lg p-4 max-w-2xl mx-auto">
              <div className="flex items-center justify-center gap-2 mb-2">
                <Zap className="text-green-400" size={20} />
                <span className="text-green-300 font-bold" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}>
                  HACKBOT ACTIVATED
                </span>
              </div>
              <p className="text-green-200 text-sm">
                Our AI analyzes each platform's unique patterns for maximum accuracy
              </p>
            </div>
          </div>

          {/* Platform Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mb-8">
            {platforms.map((platform, index) => (
              <button
                key={index}
                onClick={() => handlePlatformClick(platform.name)}
                className="relative bg-black/50 backdrop-blur-sm border border-white/20 hover:border-red-500 rounded-xl p-6 transition-all duration-300 transform hover:scale-105 hover:shadow-lg hover:bg-red-900/30"
              >
                {platform.popular && (
                  <div className="absolute -top-2 -right-2">
                    <div className="bg-yellow-500 text-black px-2 py-1 rounded-full text-xs font-bold flex items-center gap-1">
                      <Crown size={12} />
                      Popular
                    </div>
                  </div>
                )}
                
                <div className="text-center">
                  <div className="text-4xl mb-3">{platform.logo}</div>
                  <h3 className="text-white font-bold text-sm mb-2" style={{ fontFamily: 'Orbitron, monospace' }}>
                    {platform.name}
                  </h3>
                  <div className={`w-full h-1 bg-gradient-to-r ${platform.color} rounded-full mb-2`}></div>
                  <p className="text-white/60 text-xs" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '8px' }}>
                    AI Optimized
                  </p>
                </div>
              </button>
            ))}
          </div>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-6">
            <div className="bg-black/30 backdrop-blur-sm border border-white/10 rounded-xl p-6 text-center">
              <div className="text-4xl mb-4">🎯</div>
              <h3 className="text-white font-bold mb-2" style={{ fontFamily: 'Orbitron, monospace' }}>
                Platform Specific
              </h3>
              <p className="text-white/60 text-sm">
                Tailored algorithms for each platform's unique patterns
              </p>
            </div>
            
            <div className="bg-black/30 backdrop-blur-sm border border-white/10 rounded-xl p-6 text-center">
              <div className="text-4xl mb-4">⚡</div>
              <h3 className="text-white font-bold mb-2" style={{ fontFamily: 'Orbitron, monospace' }}>
                Real-Time Sync
              </h3>
              <p className="text-white/60 text-sm">
                Synchronized with live game data for instant signals
              </p>
            </div>
            
            <div className="bg-black/30 backdrop-blur-sm border border-white/10 rounded-xl p-6 text-center">
              <div className="text-4xl mb-4">🔒</div>
              <h3 className="text-white font-bold mb-2" style={{ fontFamily: 'Orbitron, monospace' }}>
                Secure & Private
              </h3>
              <p className="text-white/60 text-sm">
                Your platform choice and data remain completely private
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default PlatformSelectionScreen;