import React, { useState, useEffect, useRef } from 'react';
import { Dice6, Menu, X, Crown, BarChart3, Clock, Zap, Target, Gamepad2, Shield, Wifi, Globe, Heart, Settings } from 'lucide-react';
import PricingModal from './PricingModal';
import AnalyticsModal from './AnalyticsModal';
import CountryClockModal from './CountryClockModal';
import { useUserData } from '../hooks/useUserData';
import { scheduleSignalNotification } from '../utils/notifications';

interface SignalGeneratorProps {
  selectedPlatform: string;
}

const SignalGenerator: React.FC<SignalGeneratorProps> = ({ selectedPlatform }) => {
  const { user, loading, addSignal, canGenerateSignal, isSubscriptionActive } = useUserData();
  const [signal, setSignal] = useState('1.00X');
  const [isGenerating, setIsGenerating] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState(0);
  const [nextSignalTime, setNextSignalTime] = useState<Date | null>(null);
  const [isSignalActive, setIsSignalActive] = useState(false);
  const [showAccurateSignals, setShowAccurateSignals] = useState(false);
  const [specialUsedCount, setSpecialUsedCount] = useState(0);
  const [showPricingModal, setShowPricingModal] = useState(false);
  const [showAnalyticsModal, setShowAnalyticsModal] = useState(false);
  const [showMenu, setShowMenu] = useState(false);
  const [showCountryModal, setShowCountryModal] = useState(false);
  const [selectedCountry, setSelectedCountry] = useState('India');
  const [selectedTimezone, setSelectedTimezone] = useState('Asia/Kolkata');
  const [currentTime, setCurrentTime] = useState(new Date());
  const [isHacking, setIsHacking] = useState(false);
  const [hackingProgress, setHackingProgress] = useState(0);
  const [hackingStage, setHackingStage] = useState('');
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const clockRef = useRef<NodeJS.Timeout | null>(null);

  const isFreeLimitReached = !canGenerateSignal();

  // Real-time clock update
  useEffect(() => {
    clockRef.current = setInterval(() => {
      // Update time based on selected timezone
      const now = new Date();
      const timeInTimezone = new Date(now.toLocaleString("en-US", {timeZone: selectedTimezone}));
      setCurrentTime(timeInTimezone);
    }, 1000);

    return () => {
      if (clockRef.current) {
        clearInterval(clockRef.current);
      }
    };
  }, []);

  // Timer countdown effect
  useEffect(() => {
    if (nextSignalTime && timeRemaining > 0) {
      timerRef.current = setInterval(() => {
        const now = new Date().getTime();
        const distance = nextSignalTime.getTime() - now;
        
        if (distance > 0) {
          setTimeRemaining(Math.ceil(distance / 1000));
        } else {
          setTimeRemaining(0);
          setIsSignalActive(true);
          setNextSignalTime(null);
          
          // Auto-deactivate signal after 30 seconds
          setTimeout(() => {
            setIsSignalActive(false);
          }, 30000);
        }
      }, 1000);
    }

    return () => {
      if (timerRef.current) {
        clearInterval(timerRef.current);
      }
    };
  }, [nextSignalTime, timeRemaining]);

  // Create audio context for sound
  useEffect(() => {
    // Create a simple beep sound
    const createBeepSound = () => {
      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)();
      const oscillator = audioContext.createOscillator();
      const gainNode = audioContext.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.destination);
      
      oscillator.frequency.value = 800;
      oscillator.type = 'sine';
      
      gainNode.gain.setValueAtTime(0.1, audioContext.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.currentTime + 0.1);
      
      oscillator.start(audioContext.currentTime);
      oscillator.stop(audioContext.currentTime + 0.1);
    };

    audioRef.current = { play: createBeepSound } as any;
  }, []);

  const getSignalColor = (value: number) => {
    if (value >= 1.00 && value <= 1.99) return 'text-red-300';
    if (value >= 2.00 && value <= 4.99) return 'text-yellow-300';
    if (value >= 5.00 && value <= 9.99) return 'text-green-300';
    if (value >= 10.00 && value <= 49.99) return 'text-purple-300';
    if (value >= 50.00) return 'text-transparent bg-gradient-to-r from-red-500 via-yellow-500 via-green-500 via-blue-500 to-purple-500 bg-clip-text';
    return 'text-white';
  };

  const getSignalGlow = (value: number) => {
    if (value >= 1.00 && value <= 1.99) return 'drop-shadow-[0_0_10px_rgba(252,165,165,0.7)]';
    if (value >= 2.00 && value <= 4.99) return 'drop-shadow-[0_0_10px_rgba(253,224,71,0.7)]';
    if (value >= 5.00 && value <= 9.99) return 'drop-shadow-[0_0_10px_rgba(134,239,172,0.7)]';
    if (value >= 10.00 && value <= 49.99) return 'drop-shadow-[0_0_10px_rgba(196,181,253,0.7)]';
    if (value >= 50.00) return 'drop-shadow-[0_0_20px_rgba(255,255,255,0.8)]';
    return '';
  };

  const generateNormalSignal = () => {
    // Platform-specific signal generation for maximum accuracy
    const platformPatterns: { [key: string]: () => number } = {
      '1xBet': () => {
        // 1xBet pattern: 70% chance 1.20X-2.50X, 30% chance 1.00X-5.00X
        return Math.random() < 0.7 ? 
          parseFloat((Math.random() * 1.3 + 1.2).toFixed(2)) : 
          parseFloat((Math.random() * 4 + 1).toFixed(2));
      },
      'Parimatch': () => {
        // Parimatch pattern: 65% chance 1.15X-2.80X, 35% chance 1.00X-6.00X
        return Math.random() < 0.65 ? 
          parseFloat((Math.random() * 1.65 + 1.15).toFixed(2)) : 
          parseFloat((Math.random() * 5 + 1).toFixed(2));
      },
      'Betway': () => {
        // Betway pattern: 75% chance 1.10X-2.20X, 25% chance 1.00X-4.50X
        return Math.random() < 0.75 ? 
          parseFloat((Math.random() * 1.1 + 1.1).toFixed(2)) : 
          parseFloat((Math.random() * 3.5 + 1).toFixed(2));
      },
      'Melbet': () => {
        // Melbet pattern: 68% chance 1.25X-2.75X, 32% chance 1.00X-5.50X
        return Math.random() < 0.68 ? 
          parseFloat((Math.random() * 1.5 + 1.25).toFixed(2)) : 
          parseFloat((Math.random() * 4.5 + 1).toFixed(2));
      },
      '1Win': () => {
        // 1Win pattern: 72% chance 1.18X-2.60X, 28% chance 1.00X-4.80X
        return Math.random() < 0.72 ? 
          parseFloat((Math.random() * 1.42 + 1.18).toFixed(2)) : 
          parseFloat((Math.random() * 3.8 + 1).toFixed(2));
      }
    };
    
    // Use platform-specific pattern or default
    const patternGenerator = platformPatterns[selectedPlatform];
    if (patternGenerator) {
      return patternGenerator();
    }
    
    // Default pattern for unlisted platforms
    return Math.random() < 0.65 ? 
      parseFloat((Math.random() * 1.3 + 1.2).toFixed(2)) : 
      parseFloat((Math.random() * 4 + 1).toFixed(2));
  };

  const generateSpecialSignal = () => {
    // Platform-specific high-value signals
    const specialPatterns: { [key: string]: () => number } = {
      '1xBet': () => parseFloat((Math.random() * 15 + 5).toFixed(2)), // 5.00X-20.00X
      'Parimatch': () => parseFloat((Math.random() * 18 + 6).toFixed(2)), // 6.00X-24.00X
      'Betway': () => parseFloat((Math.random() * 12 + 4).toFixed(2)), // 4.00X-16.00X
      'Melbet': () => parseFloat((Math.random() * 20 + 7).toFixed(2)), // 7.00X-27.00X
      '1Win': () => parseFloat((Math.random() * 16 + 5.5).toFixed(2)) // 5.50X-21.50X
    };
    
    const patternGenerator = specialPatterns[selectedPlatform];
    return patternGenerator ? patternGenerator() : parseFloat((Math.random() * 15 + 5).toFixed(2));
  };

  const generateMegaSignal = () => {
    // Platform-specific mega signals (every 15th)
    const megaPatterns: { [key: string]: () => number } = {
      '1xBet': () => parseFloat((Math.random() * 60 + 25).toFixed(2)), // 25.00X-85.00X
      'Parimatch': () => parseFloat((Math.random() * 70 + 30).toFixed(2)), // 30.00X-100.00X
      'Betway': () => parseFloat((Math.random() * 50 + 20).toFixed(2)), // 20.00X-70.00X
      'Melbet': () => parseFloat((Math.random() * 80 + 35).toFixed(2)), // 35.00X-115.00X
      '1Win': () => parseFloat((Math.random() * 65 + 28).toFixed(2)) // 28.00X-93.00X
    };
    
    const patternGenerator = megaPatterns[selectedPlatform];
    return patternGenerator ? patternGenerator() : parseFloat((Math.random() * 60 + 25).toFixed(2));
  };

  const simulateHacking = () => {
    setIsHacking(true);
    setHackingProgress(0);
    
    const hackingStages = [
      'Connecting to platform...',
      'Bypassing security protocols...',
      'Accessing game server...',
      'Analyzing pattern algorithms...',
      'Extracting signal data...',
      'Calculating optimal timing...',
      'Signal ready!'
    ];
    
    let currentStage = 0;
    const stageInterval = setInterval(() => {
      if (currentStage < hackingStages.length) {
        setHackingStage(hackingStages[currentStage]);
        setHackingProgress(((currentStage + 1) / hackingStages.length) * 100);
        currentStage++;
      } else {
        clearInterval(stageInterval);
        setIsHacking(false);
        setHackingProgress(100);
        setHackingStage('');
      }
    }, 500);
  };

  const generateSignal = () => {
    if (isFreeLimitReached) {
      setShowPricingModal(true);
      return;
    }

    setIsGenerating(true);
    setIsSignalActive(false);
    
    // Start hacking simulation
    simulateHacking();
    
    // Play sound
    if (audioRef.current) {
      audioRef.current.play();
    }

    setTimeout(() => {
      let newSignal: number;
      
      const generationCount = user?.total_signal_count || 0;
      
      // Check if we should generate a special signal (5.00X-25.00X)
      // Can appear any two times within signals 1-15
      if (generationCount < 15 && specialUsedCount < 2) {
        // 18% chance for special signal in first 15 signals (platform optimized)
        if (Math.random() < 0.18) {
          newSignal = generateSpecialSignal();
          setSpecialUsedCount(prev => prev + 1);
        } else {
          newSignal = generateNormalSignal();
        }
      } else if (generationCount > 0 && (generationCount + 1) % 15 === 0) {
        // Every 15th signal: Platform-specific mega signal
        newSignal = generateMegaSignal();
      } else {
        // Regular signals: platform-specific patterns
        newSignal = generateNormalSignal();
      }

      const newSignalString = newSignal.toFixed(2) + 'X';
      setSignal(newSignalString);
      
      // Set EXACTLY 10-second timer for next signal (changed from 45 to 15)
      const exactDelay = 10; // EXACTLY 10 seconds - no more, no less
      const signalTime = new Date(Date.now() + exactDelay * 1000);
      setNextSignalTime(signalTime);
      setTimeRemaining(exactDelay);
      
      // Send notification for high-value signals
      scheduleSignalNotification(newSignalString);
      
      // Add signal to user data
      addSignal(newSignalString, selectedPlatform);
      
      setIsGenerating(false);
    }, 3500);
  };

  const signalValue = parseFloat(signal.replace('X', ''));

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const getPlatformColor = (platform: string) => {
    const colors: { [key: string]: string } = {
      '1xBet': 'from-blue-600 to-blue-700',
      'Parimatch': 'from-yellow-600 to-yellow-700',
      'Betway': 'from-green-600 to-green-700',
      'Melbet': 'from-red-600 to-red-700',
      '1Win': 'from-purple-600 to-purple-700',
      'Mostbet': 'from-indigo-600 to-indigo-700',
      'Betano': 'from-orange-600 to-orange-700',
      'Dafabet': 'from-pink-600 to-pink-700',
      'BC.Game': 'from-cyan-600 to-cyan-700',
      'Stake.com': 'from-emerald-600 to-emerald-700'
    };
    return colors[platform] || 'from-red-600 to-red-700';
  };

  const formatClock = (date: Date, timezone: string) => {
    return date.toLocaleTimeString('en-US', {
      timeZone: timezone,
      hour12: true,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    });
  };

  const handleDonate = () => {
    // Create UPI payment URL for donation
    const donationUrl = `upi://pay?pa=6002351966@ibl&pn=Chetan%20Agarwalla&cu=INR&tn=Donation%20for%20Aviator%20Hackbot`;
    
    // Try to open payment app
    window.location.href = donationUrl;
  };

  const handleCountrySelect = (country: string, timezone: string) => {
    setSelectedCountry(country);
    setSelectedTimezone(timezone);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-red-900 via-black to-red-800 relative overflow-hidden">
      {/* Animated zig-zag lines */}
      <div className="absolute inset-0 opacity-20">
        <div className="absolute top-0 left-0 w-full h-full">
          <div className="absolute top-1/4 left-0 w-full h-px bg-white animate-pulse transform skew-y-1"></div>
          <div className="absolute top-1/2 left-0 w-full h-px bg-white animate-pulse transform -skew-y-1" style={{ animationDelay: '1s' }}></div>
          <div className="absolute top-3/4 left-0 w-full h-px bg-white animate-pulse transform skew-y-1" style={{ animationDelay: '2s' }}></div>
        </div>
      </div>

      {/* Real-Time Clock - Top Right */}
      <div className="absolute top-6 right-6 z-20">
        <button
          onClick={() => setShowCountryModal(true)}
          className="bg-black/70 backdrop-blur-sm border border-green-500/50 rounded-lg px-3 py-1.5 hover:bg-black/80 transition-all duration-300"
        >
          <div className="flex items-center gap-2">
            <Globe className="text-green-400" size={12} />
            <span className="text-green-300 font-bold" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}>
              {formatClock(currentTime, selectedTimezone)}
            </span>
          </div>
          <div className="text-center">
            <span className="text-green-200" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '6px' }}>
              {selectedCountry.toUpperCase()}
            </span>
          </div>
        </button>
      </div>

      {/* Top navigation */}
      <div className="absolute top-6 left-6 right-32 z-10 flex justify-between">
        {/* Left menu */}
        <div className="flex items-center gap-3">
          {/* Menu button - moved to first position */}
          <div className="relative">
            <button
              onClick={() => setShowMenu(!showMenu)}
              className="bg-black/50 backdrop-blur-sm border border-white/20 rounded-lg p-2 text-white hover:bg-black/70 transition-all duration-300"
            >
              <Menu size={16} />
            </button>
            
            {showMenu && (
              <div className="absolute top-12 left-0 bg-black/80 backdrop-blur-sm border border-red-500/30 rounded-lg p-4 min-w-[200px] shadow-2xl">
                <div className="space-y-2">
                  <button
                    onClick={() => {
                      setShowPricingModal(true);
                      setShowMenu(false);
                    }}
                    className="w-full text-left text-white hover:text-yellow-300 py-2 px-3 rounded hover:bg-yellow-500/20 transition-all duration-300 flex items-center gap-3"
                    style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}
                  >
                    <Crown size={14} className="text-yellow-400" />
                    Upgrade Plan
                  </button>
                  
                  <button
                    onClick={() => {
                      setShowAnalyticsModal(true);
                      setShowMenu(false);
                    }}
                    className="w-full text-left text-white hover:text-blue-300 py-2 px-3 rounded hover:bg-blue-500/20 transition-all duration-300 flex items-center gap-3"
                    style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}
                  >
                    <BarChart3 size={14} className="text-blue-400" />
                    View Analytics
                  </button>
                  
                  <button
                    onClick={() => {
                      setShowAccurateSignals(!showAccurateSignals);
                      setShowMenu(false);
                    }}
                    className="w-full text-left text-white hover:text-green-300 py-2 px-3 rounded hover:bg-green-500/20 transition-all duration-300 flex items-center gap-3"
                    style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}
                  >
                    <Target size={14} className="text-green-400" />
                    {showAccurateSignals ? 'Deactivate Hackbot' : 'Activate Hackbot'}
                  </button>
                  
                  <button
                    onClick={() => {
                      handleDonate();
                      setShowMenu(false);
                    }}
                    className="w-full text-left text-white hover:text-pink-300 py-2 px-3 rounded hover:bg-pink-500/20 transition-all duration-300 flex items-center gap-3"
                    style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}
                  >
                    <Heart size={14} className="text-pink-400" />
                    Donate Money !!
                  </button>
                </div>
              </div>
            )}
          </div>
          
          {/* Platform badge - moved to second position */}
          <div className={`bg-gradient-to-r ${getPlatformColor(selectedPlatform)} px-4 py-2 rounded-lg border border-white/20`}>
            <div className="flex items-center gap-2">
              <Gamepad2 size={14} className="text-white" />
              <span className="text-white font-bold" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '8px' }}>
                {selectedPlatform}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Main content */}
      <div className="flex flex-col items-center justify-center min-h-screen px-4">
        <div className="text-center mb-8">
          <h2 className="text-4xl md:text-6xl font-bold text-white mb-4 drop-shadow-[0_0_20px_rgba(255,255,255,0.3)]" style={{ fontFamily: 'Orbitron, monospace' }}>
            AVIATOR HACKBOT
          </h2>
          <p className="text-red-300 text-lg mb-2" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '14px' }}>
            {selectedPlatform} Signal Generator
          </p>
          
          <div className="flex justify-center items-center gap-4 mb-4">
            <div className="bg-green-900/30 border border-green-500/50 rounded-lg px-4 py-2">
              <div className="flex items-center gap-2">
                <Wifi className="text-green-400 animate-pulse" size={16} />
                <span className="text-green-300 text-sm font-bold" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}>
                  CONNECTED TO {selectedPlatform.toUpperCase()}
                </span>
              </div>
            </div>
            
            {showAccurateSignals && (
              <div className="bg-green-900/30 border border-green-500/50 rounded-lg px-4 py-2">
                <div className="flex items-center gap-2">
                  <Target className="text-green-400 animate-pulse" size={16} />
                  <span className="text-green-300 text-sm font-bold animate-pulse drop-shadow-[0_0_10px_rgba(134,239,172,0.8)]" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}>
                    HACKBOT ACTIVE
                  </span>
                </div>
              </div>
            )}
          </div>
          
          {/* Free tier limitation notice */}
          {!isSubscriptionActive() && user && (
            <div className="mt-4 bg-black/30 backdrop-blur-sm border border-red-500/30 rounded-lg p-3 max-w-md mx-auto">
              {user.daily_signal_count >= 5 ? (
                <>
                  <p className="text-red-300 text-sm mb-2" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}>
                    Daily limit reached (5/5 signals used)
                  </p>
                  <button
                    onClick={() => setShowPricingModal(true)}
                    className="text-red-400 hover:text-red-300 underline text-xs"
                  >
                    Upgrade for Unlimited Signals
                  </button>
                </>
              ) : (
                <div className="text-center">
                  <p className="text-green-300 text-sm mb-1" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}>
                    Free Plan: {user.daily_signal_count}/5 signals used today
                  </p>
                  <div className="w-full bg-gray-700 rounded-full h-2 mb-2">
                    <div 
                      className="bg-green-500 h-2 rounded-full transition-all duration-300"
                      style={{ width: `${(user.daily_signal_count / 5) * 100}%` }}
                    ></div>
                  </div>
                  <p className="text-white/60 text-xs">
                    {5 - user.daily_signal_count} signals remaining today
                  </p>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Hacking Progress Display */}
        {isHacking && (
          <div className="mb-8 bg-black/70 backdrop-blur-sm border border-red-500/50 rounded-xl p-6 max-w-md mx-auto">
            <div className="text-center">
              <div className="flex items-center justify-center gap-2 mb-4">
                <Shield className="text-red-400 animate-spin" size={24} />
                <span className="text-red-300 font-bold" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}>
                  HACKING {selectedPlatform.toUpperCase()}
                </span>
              </div>
              
              <div className="mb-4">
                <div className="w-full bg-gray-700 rounded-full h-3">
                  <div 
                    className="bg-gradient-to-r from-red-500 to-yellow-500 h-3 rounded-full transition-all duration-500"
                    style={{ width: `${hackingProgress}%` }}
                  ></div>
                </div>
                <div className="text-red-300 text-sm mt-2" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}>
                  {Math.round(hackingProgress)}% Complete
                </div>
              </div>
              
              <div className="text-yellow-300 text-sm animate-pulse" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}>
                {hackingStage}
              </div>
            </div>
          </div>
        )}

        {/* Signal Display */}
        <div className={`bg-gradient-to-br from-black/70 to-black/50 backdrop-blur-sm border rounded-2xl p-8 shadow-2xl mb-8 min-w-[300px] ${
          isSignalActive ? 'border-green-500 ring-2 ring-green-500/50 animate-pulse' : 'border-white/20'
        }`}>
          <div className="text-center">
            {isSignalActive && (
              <div className="mb-4">
                <div className="bg-green-600 text-white px-4 py-2 rounded-full inline-flex items-center gap-2 animate-bounce">
                  <Zap size={16} />
                  <span className="font-bold text-sm" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}>
                    SIGNAL ACTIVE - BET NOW!
                  </span>
                </div>
              </div>
            )}
            
            <div className="text-6xl md:text-8xl font-bold" style={{ fontFamily: 'Press Start 2P, monospace' }}>
              <span className={`${getSignalColor(signalValue)} ${getSignalGlow(signalValue)}`}>
                {signal}
              </span>
            </div>
            
            {/* Timer Display */}
            {timeRemaining > 0 && (
              <div className="mt-6 bg-black/50 border border-blue-500/30 rounded-lg p-4">
                <div className="flex items-center justify-center gap-2 mb-2">
                  <Clock className="text-blue-400" size={20} />
                  <span className="text-blue-300 font-bold" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}>
                    NEXT SIGNAL IN
                  </span>
                </div>
                <div className="text-3xl font-bold text-blue-400" style={{ fontFamily: 'Press Start 2P, monospace' }}>
                  {formatTime(timeRemaining)}
                </div>
                <div className="w-full bg-gray-700 rounded-full h-2 mt-3">
                  <div 
                    className="bg-blue-500 h-2 rounded-full transition-all duration-1000"
                    style={{ width: `${((10 - timeRemaining) / 10) * 100}%` }}
                  ></div>
                </div>
                <div className="text-blue-200 text-xs mt-2" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '8px' }}>
                  Exactly 10 seconds - Perfect timing!
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Generate Button */}
        <button
          onClick={generateSignal}
          disabled={isGenerating || timeRemaining > 0 || isHacking}
          className={`bg-gradient-to-r ${getPlatformColor(selectedPlatform)} hover:opacity-90 disabled:from-gray-600 disabled:to-gray-700 text-white font-bold py-4 px-8 rounded-2xl transition-all duration-300 transform hover:scale-105 disabled:scale-100 shadow-lg flex items-center gap-3 ${isGenerating ? 'animate-pulse' : ''}`}
          style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '16px', minWidth: '300px', justifyContent: 'center' }}
        >
          <div className={`${isGenerating ? 'animate-spin' : ''}`}>
            {timeRemaining > 0 ? <Clock size={24} /> : 
             isHacking ? <Shield size={24} /> : <Dice6 size={24} />}
          </div>
          {isHacking ? 'HACKING PLATFORM...' :
           isGenerating ? 'GENERATING...' : 
           timeRemaining > 0 ? `WAIT ${formatTime(timeRemaining)}` :
           isFreeLimitReached ? (isSubscriptionActive() ? 'GENERATE SIGNAL' : 'UPGRADE TO CONTINUE') : 'HACK SIGNAL'}
        </button>

        {/* Recent Signals */}
        {user?.recent_signals && user.recent_signals.length > 0 && (
          <div className="mt-8 bg-black/30 backdrop-blur-sm border border-white/10 rounded-xl p-6 max-w-md">
            <h3 className="text-white font-bold mb-4 text-center" style={{ fontFamily: 'Orbitron, monospace' }}>
              Recent Signals
            </h3>
            <div className="space-y-2">
              {user.recent_signals.slice(0, 5).map((recentSignal, index) => {
                const value = parseFloat(recentSignal.replace('X', ''));
                const signalNumber = user.total_signal_count - index;
                return (
                  <div key={index} className="flex justify-between items-center">
                    <span className="text-white/60 text-sm" style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '10px' }}>
                      #{signalNumber}
                    </span>
                    <span 
                      className={`${getSignalColor(value)} font-bold text-sm`}
                      style={{ fontFamily: 'Press Start 2P, monospace', fontSize: '12px' }}
                    >
                      {recentSignal}
                    </span>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Modals */}
      <PricingModal 
        isOpen={showPricingModal} 
        onClose={() => setShowPricingModal(false)} 
      />
      
      <AnalyticsModal
        isOpen={showAnalyticsModal}
        onClose={() => setShowAnalyticsModal(false)}
        recentSignals={user?.recent_signals || []}
        totalSignalCount={user?.total_signal_count || 0}
        dailySignalCount={user?.daily_signal_count || 0}
      />
      
      <CountryClockModal
        isOpen={showCountryModal}
        onClose={() => setShowCountryModal(false)}
        onCountrySelect={handleCountrySelect}
        selectedCountry={selectedCountry}
      />
    </div>
  );
};

export default SignalGenerator;