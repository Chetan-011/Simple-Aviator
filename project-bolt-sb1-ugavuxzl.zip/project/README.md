# Aviator Signal Generator

A premium Progressive Web App (PWA) for generating aviator game signals with accurate predictions.

## Features

- 🚀 **Premium Signal Generation** - Advanced algorithms for accurate signals
- 📱 **Progressive Web App** - Install on any device for native app experience
- 🔔 **Push Notifications** - Get notified of high-value signals
- 📊 **Analytics Dashboard** - Track your signal history and performance
- 💳 **Secure Payments** - UPI integration for premium upgrades
- 🎯 **Offline Support** - Works without internet connection

## Installation

### For Users
1. Visit the website on your mobile device
2. Tap "Add to Home Screen" when prompted
3. Or follow the manual installation guide in the app

### For Developers
```bash
npm install
npm run dev
```

## Play Store Deployment

This PWA is ready for Google Play Store deployment using Trusted Web Activity (TWA).

### Requirements for Play Store:
- ✅ PWA with valid manifest.json
- ✅ Service worker for offline functionality
- ✅ HTTPS deployment (via Netlify)
- ✅ 512x512 icon for Play Store
- ✅ Proper app categories and descriptions

### Steps to Upload to Play Store:

1. **Create Android App Bundle using PWA Builder:**
   - Visit [PWABuilder.com](https://www.pwabuilder.com/)
   - Enter your PWA URL: `https://joyful-hummingbird-a71379.netlify.app`
   - Click "Build My PWA"
   - Select "Android" and download the APK/AAB file

2. **Google Play Console Setup:**
   - Create a Google Play Developer account ($25 one-time fee)
   - Go to [Google Play Console](https://play.google.com/console)
   - Create a new app
   - Upload the generated APK/AAB file

3. **App Store Listing:**
   - App Name: "Aviator Signal Generator"
   - Short Description: "Premium aviator game signals with accurate predictions"
   - Full Description: Include features, benefits, and usage instructions
   - Category: Games > Casino
   - Content Rating: Appropriate for all audiences
   - Screenshots: Generate from the PWA interface

4. **Review and Publish:**
   - Complete all required sections
   - Submit for review (usually takes 1-3 days)
   - Once approved, your app will be live on Play Store

### Free Deployment Benefits:
- No monthly hosting costs (using Netlify free tier)
- No app store fees beyond the initial $25 developer account
- Automatic updates through PWA technology
- Cross-platform compatibility (Android, iOS, Desktop)

## Technical Stack

- **Frontend:** React + TypeScript + Tailwind CSS
- **PWA:** Vite PWA Plugin with Workbox
- **Deployment:** Netlify
- **Icons:** Lucide React
- **Fonts:** Google Fonts (Orbitron, Press Start 2P)

## License

This project is for educational purposes. Please ensure compliance with local gambling laws and regulations.